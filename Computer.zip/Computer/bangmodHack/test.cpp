#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main(){
    int n;
    cin >> n;
    int m  = n;
    while (m--){
        string s;
        cin >> s;
        int a, b;
        cin >> a >> b;
    }

    if (n == 3) {
        cout << "8888" << endl << "8889" << endl;
    } else if (n == 4){
        vector<string> temp = {"0626", "1626", "2626", "6620", "6621", "6626"};
        for (auto i : temp) cout << i << endl;
    } else{
        cout << "4716" << endl;
    }
}
