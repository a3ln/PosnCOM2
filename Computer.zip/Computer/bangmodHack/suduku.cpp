#include <iostream>
#include <vector>

using namespace std;
const int n = 9;

bool check(vector<string> grid, int ii, int jj){
    vector<int> freq(n + 1, 0);

    for (int i = 0;i < n;i++)
        freq[grid[ii][i] - '0']++;
    for (int i = 1;i <= n;i++){
        if (freq[i] >= 2)
            return false;
        freq[i] = 0;
    }

    for (int i = 0;i < n;i++)
        freq[grid[i][jj] - '0']++;
    for (int i = 1;i <= n;i++){
        if (freq[i] >= 2)
            return  false;
        freq[i] = 0;
    }

    for (int i = 0;i < 3;i++){
        for (int j = 0;j < 3;j++){
            freq[grid[ii / 3 + i][jj / 3 + j] - '0']++;
        }
    }
    for (int i = 1;i <= n;i++){
        if (freq[i] >= 2)
            return false;
    }
    return true;
}

bool solve(vector<string> &grid, int index){
    int ii = index / 9, jj = index % 9;
    // cout << index << '\n';
    if (grid[ii][jj] != '0'){
        return solve(grid, index + 1);
    }
    for (char i = '0';i <= '9';i++){
        grid[ii][jj] = i;
        if (check(grid, ii, jj)){
            if (solve(grid, index + 1)) return true;
        }
        grid[ii][jj] = '0';
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    vector<string> grid(n);
    for (auto &ss:grid)
        cin >> ss;

    if (solve(grid, 0)){
        for (int i = 0;i < n;i++){
            cout << "[";
            for (int j = 0;j < n;j++){
                cout << grid[i][j] << ",]"[j == n - 1];
            }
            if (i != n - 1)
                cout << ",\n";
        }
        return 0;
    }
}
