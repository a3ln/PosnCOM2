#include <iostream>
#include <cstring>
#include <set>
#include <vector>

using namespace std;

vector<string> ss;
vector<string> res;
vector<pair<string, pair<int, int>>> pp;

void recur(int st, string s){
    if (st == 4){
        ss.push_back(s);
        return ;
    }
    for (int i = 0;i <= 9;i++){
        s += char('0' + i);
        recur(st + 1, s);
        s.pop_back();
    }
}

vector<string> solve(vector<string> &str){
    string st;
    cin >> st;
    int a, b;
    cin >> a >> b; // how many right place+value, right value
    pp.push_back({st, {a, b}});

    vector<string> ans;
    for (int k = 0 ; k < str.size() ; k++){
        int ca = 0;
        for (int i = 0 ; i < 4 ; i++){
            if (str[k][i] == st[i]) ca++;
        }
        if (ca == a) ans.push_back(str[k]);
    }
    return ans;
}

vector<string> solve2(vector<string> &str){
    vector<string> ans;
    for (auto p : pp){
        auto st = p.first;
        auto [a, b] = p.second;

        b+=a;
        for (int k = 0 ; k < str.size() ; k++){
            int cb = 0;
            for (int i = 0 ; i < 4 ; i++){
                for (int j = 0 ; j < 4 ; j++){
                    if (i == j) continue;
                    if (str[k][i]==st[j]) {
                        cb++;
                        continue;
                    }
                }
            }
            if (cb == b) {
                ans.push_back(str[k]);
                // cout << ss[k] << endl;
            }
        }
    }

    return ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int q;
    cin >> q;
    int p = q;
    recur(0, "");
    // cout << ss.size() << '\n';
    while (q--){
        vector<string> temp = solve(ss);
        ss = temp;
    }
    for (auto i : ss) cout << i << endl;
    cout << endl;
    vector<string> temp = solve2(ss);
    ss = temp;
    for (auto i : ss) cout << i << endl;
}
