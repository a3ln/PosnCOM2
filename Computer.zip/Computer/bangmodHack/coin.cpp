#include<iostream>
#include<vector>
#include<math.h>
using namespace std;

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    float n, m;
    cin >> n >> m;
    vector<int> nums;
    int a, c = 0;
    while (cin >> a){
        c++;
        n-=a;
    }
    int win = 1;
    if (c%2==0) win = 2;

    int more = ceil(n/m);
    win += more;
    if (win%2==0) cout << 2;
    else cout << 1;
}
