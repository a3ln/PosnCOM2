// 77
#include<bits/stdc++.h>
using namespace std;

#define p pair<int, int>
#define int unsigned long long
int n, m, q;
vector<vector<pair<int, int>>> path;

int dijkstra(int s, int e) {
    vector<int> dis(n+1, ULLONG_MAX);
    vector<bool> vis(n+1 ,false);
    priority_queue<p, vector<p>, greater<p>> pq;
    dis[s] = 0;
    pq.push({0, s});

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (u == e && dis[e] != ULLONG_MAX) {
            // cout << "*";
            return dis[e];
        }

        if (vis[u]) continue;
        vis[u] = true;

        for (auto i : path[u]) {
            int v = i.first;
            int w = i.second;
            if (!vis[v] && dis[v]>dis[u]+w) {
                dis[v] = dis[u] + w;
                pq.push({dis[v], v});
            }
        }
    }

    // cout << "-";
    return -1;
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m >> q;
    path.resize(n+1);
    for (int i = 0 ; i < m ; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        path[a].push_back({b, c});
        path[b].push_back({a, c});
    }

    vector<int> ans;
    for (int i = 0 ; i < q ; i++) {
        int u, v;
        cin >> u >> v;
        int a = dijkstra(u, v);
        if (a == -1) {
            cout << -1 << "\n";
        } else {
            cout << a << "\n";
        }
    }

    // for (auto i : ans) cout << i << "\n";
}