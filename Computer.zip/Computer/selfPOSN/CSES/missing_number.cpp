// 79
#include<bits/stdc++.h>
using namespace std;

#define int long long

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, sum = 0;
    cin >> n;
    int ans = n*(n+1)/2;
    for (int i = 0 ; i < n-1 ; i++) {
        int a;
        cin >> a;
        sum+=a;
    }
    cout << ans-sum;
}