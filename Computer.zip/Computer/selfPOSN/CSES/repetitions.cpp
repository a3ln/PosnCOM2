// 80
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    string s;
    cin >> s;
    int ans = 1, n = s.length();
    for (int i = 0 ; i < n-1 ; i++) {
        int temp = 1;
        while (s[i]==s[i+1]) {
            temp++;
            i++;
        }
        ans = max(ans, temp);
    }
    cout << ans;
}