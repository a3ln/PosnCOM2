// 73
#include<bits/stdc++.h>
using namespace std;

vector<int> ans;
vector<int> par;
vector<int> dis;
vector<bool> vis;
vector<vector<int>> path;

void bfs(int s) {
    dis[s] = 0;
    queue<int> q;
    q.push(s);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        if (vis[u]) continue;
        vis[u] = true;

        for (auto v : path[u]) {
            if (!vis[v] && dis[v]>dis[u]+1) {
                dis[v] = dis[u]+1;
                par[v] = u;
                q.push(v);
            }
        }
    }
}

void backtrack(int u) {
    if (u == 1) return;

    ans.push_back(par[u]);
    backtrack(par[u]);
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    path.resize(n+1);
    while (m--) {
        int u, v;
        cin >> u >> v;
        path[u].push_back(v);
        path[v].push_back(u);
    }

    dis.resize(n+1, INT_MAX);
    par.resize(n+1, -1);
    vis.resize(n+1, false);
    bfs(1);

    if (vis[n]) {
        ans.push_back(n);
        backtrack(n);
        reverse(ans.begin(), ans.end());
        cout << ans.size() << "\n";
        for (auto i : ans) cout << i << " ";
    } else cout << "IMPOSSIBLE";
}

/*10 20
8 9
6 7
9 10
7 9
3 4
5 8
6 8
1 2
5 7
8 10
2 3
1 4
7 8
5 6
6 9
1 3
4 5
3 6
3 5
7 10*/