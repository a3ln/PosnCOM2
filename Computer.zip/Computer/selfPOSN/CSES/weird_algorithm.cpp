// 78
#include<bits/stdc++.h>
using namespace std;

#define int long long

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    cout << n << " ";
    while (n!=1) {
        if (n%2==0) n/=2;
        else {
            n*=3;
            n++;
        }
        cout << n << " ";
    }
}