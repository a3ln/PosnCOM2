// 72
#include<bits/stdc++.h>
using namespace std;

vector<vector<int>> path;
vector<bool> vis;

void dfs(int u) {
    vis[u] = true;

    for (auto v : path[u]) {
        if (!vis[v]) dfs(v);
    }
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    path.resize(n+1);
    while (m--) {
        int u, v;
        cin >> u >> v;
        path[u].push_back(v);
        path[v].push_back(u);
    }

    vector<int> ans;
    vis.resize(n+1, false);
    for (int i = 1 ; i <= n ; i++) {
        if (!vis[i]) {
            ans.push_back(i);
            dfs(i);
        }
    }

    int s = ans.size()-1;
    cout << s << "\n";
    for (int i = 0 ; i < s ; i++) {
        cout << ans[i] << " " << ans[i+1] << "\n";
    }
}

/*10 10
2 5
5 6
1 4
6 8
2 6
3 6
1 10
8 9
2 3
5 8*/