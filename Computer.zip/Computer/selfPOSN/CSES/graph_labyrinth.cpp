// 71
#include<bits/stdc++.h>
using namespace std;

int n, m;
pair<int, int> s, e;
vector<string> path;
vector<vector<bool>> vis;
vector<pair<int, int>> dir = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
vector<vector<char>> par;
vector<char> ans;
vector<vector<int>> dis;

void bfs(int si, int sj) {
    queue<pair<int, int>> q;
    q.push({si, sj});

    while (!q.empty()) {
        int i = q.front().first;
        int j = q.front().second;
        q.pop();

        if (vis[i][j]) continue;
        vis[i][j] = true;

        for (int k = 0 ; k < 4 ; k++) {
            int x = i+dir[k].first;
            int y = j+dir[k].second;
            if (x>=0 && x<n && y>=0 && y<m && path[x][y]!='#' && !vis[x][y] && dis[x][y]>dis[i][j]+1) {
                dis[x][y] = dis[i][j]+1;
                switch (k) {
                    case 0 : par[x][y] = 'L'; break;
                    case 1 : par[x][y] = 'R'; break;
                    case 2 : par[x][y] = 'D'; break;
                    case 3 : par[x][y] = 'U'; break;
                    default : break;
                }
                q.push({x, y});
            }
        }
    }
}

void dfs(int i, int j) {
    if (path[i][j] == 'A') return;
    if (par[i][j] == 'U') {
        ans.push_back('U');
        dfs(i+1, j);
    } else if (par[i][j] == 'D') {
        ans.push_back('D');
        dfs(i-1, j);
    } else if (par[i][j] == 'R') {
        ans.push_back('R');
        dfs(i, j-1);
    } else if (par[i][j] == 'L') {
        ans.push_back('L');
        dfs(i, j+1);
    }
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m;
    path.resize(n);
    vis.resize(n, vector<bool>(m, false));
    par.resize(n, vector<char>(m));
    dis.resize(n, vector<int>(m, INT_MAX));
    for (int i = 0 ; i < n ; i++) {
        cin >> path[i];
        for (int j = 0 ; j < m ; j++) {
            if (path[i][j] == 'A') s = {i, j};
            else if (path[i][j] == 'B') e = {i, j};
        }
    }

    dis[s.first][s.second] = 0;
    bfs(s.first, s.second);

    if (!vis[e.first][e.second]) {
        cout << "NO";
        return 0;
    }

    dfs(e.first, e.second);
    reverse(ans.begin(), ans.end());
    cout << "YES\n" << ans.size() << "\n";
    for (auto i : ans) cout << i;
}

/*5 8
########
#.A#...#
#.##.#B#
#......#
########*/
// LDDRRRRRU
// LDDRRRRRU
