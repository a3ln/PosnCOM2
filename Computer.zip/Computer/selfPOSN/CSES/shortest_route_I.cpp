// 76
#include<bits/stdc++.h>
using namespace std;

#define int unsigned long long
#define p pair<int, int>

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<p>> path(n+1);
    for (int i = 0 ; i < m ; i++){
        int a, b, c;
        cin >> a >> b >> c;
        path[a].push_back({b, c});
    }

    vector<int> dis(n+1, ULLONG_MAX);
    vector<bool> vis(n+1, false);
    priority_queue<p, vector<p>, greater<p>> pq;
    dis[1] = 0;
    pq.push({0, 1});

    while (!pq.empty()){
        int u = pq.top().second;
        pq.pop();

        if (vis[u]) continue;
        vis[u] = true;

        for (auto i : path[u]){
            int v = i.first;
            int w = i.second;
            if (!vis[v] && dis[v] > dis[u]+w){
                dis[v] = dis[u] + w;
                pq.push({dis[v], v});
            }
        }
    }

    for (int i = 1 ; i <= n ; i++) cout << dis[i] << " ";
}