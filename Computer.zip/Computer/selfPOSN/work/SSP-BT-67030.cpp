#include<bits/stdc++.h>
using namespace std;

int d = 9;
void backtrack(vector<int> &a, vector<vector<int>> &ans, vector<int> &curr, int c, int d) {
    if (d == 0) {
        ans.push_back(curr);
        return;
    }
    if (c==a.size()) {
        return;
    }
    backtrack(a, ans, curr, c+1, d);
    if (a[c] <= d) {
        curr.push_back(a[c]);
        backtrack(a, ans, curr, c+1, d-a[c]);
        curr.pop_back();
    }
}

int main() {
    vector<int> a = {1,2,5,6,8};
    sort(a.begin(), a.end());

    vector<vector<int>> ans;
    vector<int> curr;
    backtrack(a,ans, curr, 0, d);
    for (auto i : ans) {
        for (auto j : i) {
            cout << j << " ";
        }
        cout << "\n";
    }
}