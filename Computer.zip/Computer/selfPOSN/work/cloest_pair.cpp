#include<bits/stdc++.h>
using namespace std;

#define ll long long
ll closet_pair(vector<pair<ll, ll>> &info, int n){
    sort(info.begin(), info.end());

    // y x
    set<pair<ll, ll>> s;
    ll dis = LLONG_MAX;
    ll j = 0;

    for (ll i = 0 ; i < n ; i++){
        ll d = ceil(sqrt(dis));
        while(info[i].first-info[j].second >= d){
            s.erase({info[j].second, info[j].first});
            j++;
        }

        auto start = s.lower_bound({info[i].second-d, info[i].first});
        auto end = s.upper_bound({info[i].second+d, info[i].first});

        for (auto it = start ; it != end ; it++){
            ll dx = info[i].first - it->second;
            ll dy = info[i].second - it->first;
            dis = min(dis, 1LL*dx*dx + 1LL*dy*dy);
        }
        // y x
        s.insert({info[i].second, info[i].first});
    }
    return dis;
}

int main(){
    vector<pair<ll ,ll>> info = {
        { 1, 2 }, { 2, 3 }, { 3, 4 }, { 5, 6 }, { 2, 1 }
    };
    int n = info.size();

    cout << closet_pair(info, n) << "\n";
}