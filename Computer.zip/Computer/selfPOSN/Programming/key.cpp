// 46
#include<bits/stdc++.h>
using namespace std;

string a, b;
vector<vector<int>> dp;

/* case 1 : both a[i] and b[j] is equal to s[k]
 *   - check two of them -> i+1 || j+1 (k+1) if true
 * case 2 : only a[i] is equal to s[k]
 *   - check a[i] -> i+1 (k+1) if true
 * case 3 : only b[j] is equal to s[k]
 *   - check b[j] -> j+1 (k+1) if true
 * case 4 : none is euqal to s[k]
 *   - return "false"
 *
 * base case : if (i == a.size() && j == b.size() && k == s.size())
 *   - return "true"
 */

bool solve(string &s, int i, int j, int k) {
    // cout << i << "-" << j << " : " << k << "\n";
    if (i == a.size() && j == b.size() && k == s.size()) return true;

    if (dp[i][j]!=-1) return dp[i][j];

    if (i<a.size() && j<b.size() && a[i]==s[k] && b[j]==s[k]) return dp[i][j] = solve(s, i+1, j, k+1) || solve(s, i, j+1, k+1);
    if (i<a.size() && a[i]==s[k]) return dp[i][j] = solve(s, i+1, j, k+1);
    if (j<b.size() && b[j]==s[k]) return dp[i][j] = solve(s, i, j+1, k+1);

    return dp[i][j] = false;
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> a >> b;
    int n;
    cin >> n;
    while (n--) {
        dp.assign(a.size()+1, vector<int>(b.size()+1, -1));
        string s;
        cin >> s;

        if (solve(s, 0, 0, 0)) cout << "Yes\n";
        else cout << "No\n";
    }
}

/*BAB
AB
4
BAABB
BABAB
ABBAB
BBABA*/