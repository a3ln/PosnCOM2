#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    vector<char> ans;
    for (int i = 0 ; i < 5 ; i++) {
        int n;
        cin >> n;
        vector<pair<int, int>> path(n+1);
        vector<pair<int, int>> path2(n+1);
        vector<int> edge(2*(n-1));
        for (int j = 0 ; j < 2*(n-1) ; j++) {
            cin >> edge[j];
            if (j%2==1) {
                // edge[j] is min
                if (edge[j]>edge[j-1]) swap(edge[j], edge[j-1]);
                path.push_back({edge[j], edge[j-1]});
            }
        }
        for (int j = 0 ; j < 2*(n-1) ; j++) {
            cin >> edge[j];
            if (j%2==1) {
                if (edge[j]>edge[j-1]) swap(edge[j], edge[j-1]);
                path2.push_back({edge[j], edge[j-1]});
            }
        }
        sort(path.begin(), path.end());
        sort(path2.begin(), path2.end());
        if (path == path2) ans.push_back('Y');
        else ans.push_back('N');
    }

    for (auto i : ans) {
        cout << i;
    }
}