#include<bits/stdc++.h>
using namespace std;

int n, m;
vector<vector<double>> price;
vector<vector<bool>> visited;
double check(int k) {
    if (k == 0) {
        return 0.0;
    }

    double minn = DBL_MAX;
    for (int x = 1 ; x <= n ; x++) {
        for (int y = 1 ; y <= m ;y++) {
            if (!visited[x][y]) {
                visited[x][y] = true;
                price[x-1][y] += price[x][y]*0.1;
                price[x][y-1] += price[x][y]*0.1;
                price[x+1][y] += price[x][y]*0.1;
                price[x][y+1] += price[x][y]*0.1;
                price[x+1][y+1] += price[x][y]*0.1;
                price[x-1][y-1] += price[x][y]*0.1;
                price[x-1][y+1] += price[x][y]*0.1;
                price[x+1][y-1] += price[x][y]*0.1;

                minn = min(minn, price[x][y]+check(k-1));

                visited[x][y] = false;
                price[x-1][y] -= price[x][y]*0.1;
                price[x][y-1] -= price[x][y]*0.1;
                price[x+1][y] -= price[x][y]*0.1;
                price[x][y+1] -= price[x][y]*0.1;
                price[x+1][y+1] -= price[x][y]*0.1;
                price[x-1][y-1] -= price[x][y]*0.1;
                price[x-1][y+1] -= price[x][y]*0.1;
                price[x+1][y-1] -= price[x][y]*0.1;
            }
        }
    }

    return minn;
}

int main() {
    cin >> n >> m;
    visited.resize(n+2, vector<bool>(m+2, false));
    price.resize(n+2, vector<double>(m+2, 0));
    for (int i = 1 ;  i<= n; i++) {
        for (int j = 1 ; j <= m ; j++) {
            cin >> price[i][j];
        }
    }

    double ans = check(n*m);
    printf("%.2lf", ans);
}