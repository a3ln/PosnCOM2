// 56
#include<bits/stdc++.h>
using namespace std;

#define int long long
#define pp pair<int, int>
int n, m;
int ans = INT_MAX;
vector<vector<pair<int, int>>> path;
vector<int> dis;

void dijkstra() {
    vector<bool> vis(n, false);
    priority_queue<pp, vector<pp>, greater<pp>> pq;

    dis[0] = 0;
    pq.push({0, 0});
    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (vis[u]) continue;
        vis[u] = true;

        for (auto i : path[u]) {
            int v = i.first;
            int w = i.second;
            if (!vis[v] && dis[v]>dis[u]+w) {
                dis[v] = dis[u]+w;
                pq.push({dis[v], v});
            }
        }
    }
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m;
    path.resize(n);
    for (int i = 0 ; i < m ; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        path[u].push_back({v, w});
        path[v].push_back({u, w});
    }
    dis.resize(n, INT_MAX);
    dijkstra();
    // for (auto i : dis) {
    //     cout << i << " ";
    // }
    int k;
    cin >> k;
    while (k--) {
        int s, p;
        cin >> s >> p;
        ans = min(ans, dis[s]+p);
    }

    cout << ans;
}

/*4
4
1 0 80
1 2 40
2 0 20
0 3 90
3
1 120
0 200
3 100*/