#include<bits/stdc++.h>
using namespace std;

#define int long long
#define tup tuple<int, int, int>
int n;
int sX, sY, sZ;
int m;
vector<pair<tup, tup>> shop;
int minn = INT_MAX;
vector<bool> visited;
void walk(tup peice, tup pos, int dis) {
    int X,Y,Z;
    tie(X, Y, Z) = pos;
    int a, b, c;
    tie(a, b, c) = peice;
    if (a>=n && b>=n && c>=n) {
        minn = min(minn, dis);
        return;
    }

    int d, e, f;
    int x, y, z;
    for (int i = 0 ; i < m ; i++) {
        if (visited[i]) continue;
        visited[i] = true;
        tie(x, y ,z) = shop[i].first;
        tie(d, e, f) = shop[i].second;
        walk({a+d, b+e, c+f}, {x, y, z}, dis+(x-X)*(x-X)+(y-Y)*(y-Y)+(z-Z)*(z-Z));
        visited[i] = false;
    }
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n;
    cin >> sX >> sY >> sZ;
    cin >> m;
    // x,y,z and a,b,c
    shop.resize(m);
    visited.resize(m, false);
    for (int i = 0 ; i < m ; i++) {
        cin >> get<0>(shop[i].first) >> get<1>(shop[i].first) >> get<2>(shop[i].first);
        cin >> get<0>(shop[i].second) >> get<1>(shop[i].second) >> get<2>(shop[i].second);
    }

    walk({0, 0, 0}, {sX, sY, sZ}, 0);
    cout << minn;
}