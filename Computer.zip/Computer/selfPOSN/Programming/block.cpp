// 55
// i am too lazy -> toi3_block
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<char>> block(n, vector<char>(m));
    for (int i = 0 ; i < n ; i++) {
        for (int j = 0 ; j < m ; j++) {
            cin >> block[i][j];
        }
    }
    int q;
    cin >> q;

    while (q--) {
        int v, l, d;
        cin >> v >> l >> d;

    }
}