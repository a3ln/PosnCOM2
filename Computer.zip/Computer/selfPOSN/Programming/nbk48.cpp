// 40
#include<bits/stdc++.h>
using namespace std;

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, q;
    cin >> n >> q;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    for (int i = 1 ; i < n ; i++) {
        info[i] += info[i-1];
    }

    for (int i = n-1 ; i > 0 ; i--) {
        if (info[i-1]>info[i]) info[i-1] = info[i];
    }

    for (int i = 0 ; i < q ; i++) {
        int a;
        cin >> a;

        auto ans = upper_bound(info.begin(), info.end(), a);
        cout << ans-info.begin() << "\n";
    }
}