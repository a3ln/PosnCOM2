#include<bits/stdc++.h>
using namespace std;

#define int long long
bool check(vector<int> &info, int mid, int n) {
    int sum = 0;
    int c = 1;
    for (auto i : info) {
        if (sum+i>mid) {
            sum = 0;
            c++;
        }
        if (c>n) return false;
        sum+=i;
    }
    if (c<=n) return true;
    return false;
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<int> info(m);
    int maxx = INT_MIN;
    int sum = 0;
    for (int i = 0 ; i < m ; i++) {
        cin >> info[i];
        maxx = max(maxx, info[i]);
        sum+=info[i];
    }

    int l = maxx, r = sum;
    int curr = r;
    while (l<=r) {
        int mid = l+(r-l)/2;
        if (check(info, mid, n)) {
            curr = mid;
            r = mid-1; //decrease
        } else {
            l = mid+1; //increase
        }
    }
    cout << curr;
}