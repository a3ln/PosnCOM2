// 45
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m; // road and traveler
    cin >> n >> m;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i]; // - is store | + is checkpoint
    }

    vector<int> ans;
    for (int i = 0 ; i < m ; i++) {
        int s, p; // start and money
        cin >> s >> p;

        int b = 0;
        while (p>0 && s<n) {
            p+=info[s];
            if (info[s]>0) b+=info[s];
            s++;
        }
        ans.push_back(b);
    }

    for (auto i : ans) {
        cout << i << "\n";
    }
}