// 82
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    int count = INT_MIN;
    vector<vector<char>> pat(n, vector<char>(70, 'o'));
    for (int i = 0 ; i < n ; i++) {
        int p, q, r;
        cin >> p >> q >> r;

        p--; q--;
        count = max(count, p);
        while (r--) {
            if (q+1 > 70) break;
            pat[p][q++] = 'x';
        }
    }

    for (int i = 0 ; i <= count ; i++) {
        for (auto j : pat[i]) cout << j;
        cout << "\n";
    }
}

/*4
1 1 10
2 3 9
3 5 25
2 20 2*/