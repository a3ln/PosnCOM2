// 83
#include <bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    double sum = 0;
    while (n--) {
        // 1, 3/4, 1/2, 1/4, 1/8
        int a, b, c, d, e;
        cin >> a >> b >> c >> d >> e;
        sum = sum + 1*a + 0.75*b + 0.5*c + 0.25*d + 0.125*e;
    }

    cout << ceil(sum);
}