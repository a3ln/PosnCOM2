#include<bits/stdc++.h>
using namespace std;

#define int long long
int n, m, k; //m is the number of the store, k is number that can get
vector<int> info;
bool check(int mid) {
    int sum = 0;
    int c = 0;
    priority_queue<int, vector<int>, greater<int>> pq;
    for (int i = 0 ; i < n ; i++) {
        sum+=info[i];
        pq.push(info[i]);
        if (pq.size()>k) {
            sum-=pq.top();
            pq.pop();
        }
        if (pq.size()==k && sum>=mid) {
            while (!pq.empty()) {
                pq.pop();
            }
            sum = 0;
            c++;
        }
    }
    if (c<m) return true;
    return false;
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m >> k;
    info.resize(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    int l = *min_element(info.begin(), info.end());
    int r = *max_element(info.begin(), info.end())*k;
    int curr = r;
    while (l<=r) {
        int mid = (r+l)/2;
        // cout << mid << "\n";
        if (check(mid)) {
            curr = mid;
            r = mid-1; //decrease
        } else {
            l = mid+1; //increase
        }
    }

    cout << l-1;
}

/*12 3 3
1
6
5
7
4
8
9
3
10
2
12
13*/