#include<bits/stdc++.h>
using namespace std;
#define int long long

bool check(int mid, vector<int> &cat) {
    stack<int> temp;
    int c = cat.size();
    for (auto i : cat) {
        if (i<=mid) {
            c--;
            continue;
        }
        if (temp.empty() || temp.top() != i) {
            temp.push(i);
        } else if (temp.top() == i) {
            c-=2;
        }
    }

    if (c!=0) return false;
    return true;
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> cat(n);
    int minn = INT_MAX;
    int maxx = INT_MIN;
    for (int i = 0 ; i < n ; i++) {
        cin >> cat[i];
        minn = min(minn, cat[i]);
        maxx = max(maxx, cat[i]);
    }

    int l = 0, r = maxx;
    int curr = r;
    while (l <= r) {
        int mid = (r+l)/2;
        if (check(mid, cat)) {
            curr = mid;
            r = mid-1; //decrease
        } else {
            l = mid+1; //increase
        }
    }
    cout << curr;
}

/*6
3
3
2
5
5
2*/