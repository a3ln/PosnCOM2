#include<bits/stdc++.h>
using namespace std;

#define int long long
int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> room(n+1, 0);
    int ans = 1;
    for (int i = 0 ; i < 2*n-1 ; i++) {
        int a;
        cin >> a;
        room[a]++;
        if (room[a]>1) {
            ans*=room[a]-1;
            ans%=int32_t(1e9+7);
        }
    }
    cout << ans%int32_t(1e9+7);
}