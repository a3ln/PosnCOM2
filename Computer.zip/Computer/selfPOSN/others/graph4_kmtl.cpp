// 44
#include<bits/stdc++.h>
using namespace std;

map<string, int> level;
map<string, vector<string>> p;

void bfs(string &s) {
    map<string, bool> visited;
    queue<pair<int, string>> q;

    q.push({0, s});
    while (!q.empty()) {
        string name = q.front().second;
        int lvl = q.front().first;
        q.pop();

        if (visited[name]) continue;
        visited[name] = true;

        level[name] = min(level[name], lvl);
        for (auto i : p[name]) {
            q.push({lvl+1, i});
        }
    }
}

int main() {
    int n, m, k;
    cin >> n >> m >> k;
    for (int i = 0 ; i < n ; i++) {
        string s1, s2;
        cin >> s1 >> s2;
        p[s1].push_back(s2);
        p[s2].push_back(s1);
        level[s1] = INT_MAX;
        level[s2] = INT_MAX;
    }

    for (int i = 0 ; i < m ; i++) {
        string s;
        cin >> s;
        bfs(s);
    }

    int c = 0;
    for (auto i : level) {
        if (i.second == k) c++;
    }
    cout << c;
}