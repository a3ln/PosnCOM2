// 42
#include<bits/stdc++.h>
using namespace std;

vector<int> parent(1e9);
int find_parent(int s) {
    if (parent[s] == s) return s;
    return find_parent(parent[s]);
}

void merge(int a, int b) {
    int pa = find_parent(a);
    int pb = find_parent(b);
    parent[pb] = pa;
}

int main() {
    for (int i = 0 ; i <= 1e9 ; i++) {
        parent[i] = i;
    }
    int n;
    cin >> n;

    int c = 0;
    for (int i = 0 ; i < n ; i++) {
        int u, v;
        cin >> u >> v;

        if (find_parent(u) != find_parent(v)) {
            merge(u, v);
            c++;
        }
    }
    cout << c;
}