// 48
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n = 4; // tools
    vector<int> cheese = {1, 2, 3, 1, 5, 6, 7, 8, 9};
    int m = cheese.size();

    if (m == 0) {
        cout << 0;
        return 0;
    }

    vector<vector<int>> dp(m, vector<int>(n+1, 0)); // cheese and tools
    // base case  without using tools
    dp[0][0] = cheese[0];
    dp[1][0] = max(cheese[0], cheese[1]);

    // normal without uisng tools
    for (int i = 2 ; i < m ; i++) {
        dp[i][0] = max(dp[i-1][0], dp[i-2][0]+cheese[i]);
    }

    // use the tools
    for (int j = 1 ; j <= n ; j++) {
        // base case
        dp[0][j] = cheese[0];
        dp[1][j] = max(cheese[0], cheese[1]);

        for (int i = 2 ; i < m ; i++) {
            // case 1 : don't use tool. Just steal it
            dp[i][j] = max(dp[i][j], dp[i-1][j]);

            // case 2 : use tool
            if (j > 0) {
                dp[i][j] = max(dp[i][j], cheese[i]+cheese[i-1]+ (i>2 ? dp[i-3][j-1] : 0));
            }

            // case 3 : don't use tool. Just steal regularly from those last house
            dp[i][j] = max(dp[i][j], cheese[i]+dp[i-2][j]);
        }
    }

    cout << dp[m-1][n];
}