#include<bits/stdc++.h>
using namespace std;

// merge back into [       ]
void Merge(vector<int> &nums, int l, int mid, int r){
    int n1 = mid-l+1;
    int n2 = r-mid;
    vector<int> L(n1), R(n2);

    for (int i = 0 ; i < n1 ; i++) L[i] = nums[l+i];
    for (int i = 0 ; i < n2 ; i++) R[i] = nums[mid+1+i];

    int i = 0, j = 0, k = l;
    while (i<n1 && j<n2){
        if (L[i]<=R[j]){
            nums[k] = L[i];
            i++;
        } else {
            nums[k] = R[j];
            j++;
        }
        k++;
    }

    while (i<n1){
        nums[k] = L[i];
        i++;
        k++;
    }
    while (j<n2){
        nums[k] = R[j];
        j++;
        k++;
    }
}

// cut the list into [] [] [] []
void mergeSort(vector<int> &nums, int l, int r){
    if (l >= r) return;

    int mid = (l+r)/2;
    mergeSort(nums, l, mid);
    mergeSort(nums, mid+1, r);
    Merge(nums, l, mid, r);
}

int main(){
    vector<int> nums = {38, 27, 43, 10};
    int n = nums.size();

    mergeSort(nums, 0, n-1);
    for (auto i : nums) cout << i << " ";
}
