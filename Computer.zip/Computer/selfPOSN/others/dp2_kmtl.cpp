// 38
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    int ans = INT_MIN;
    for (int i = 0 ; i < n ; i++) {
        int sum = info[i];
        for (int j = i+info[i] ; j < n ; ) {
            sum+=info[j];
            j+=info[j];
        }
        ans = max(ans, sum);
    }

    cout << ans;
}