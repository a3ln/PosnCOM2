#include<bits/stdc++.h>
using namespace std;

#define V vector<int>

void topoSort(int curr, vector<V> &adj, vector<bool> &vis, stack<int> &st){
    vis[curr] = true;
    for (int i : adj[curr]){
        if (!vis[i]) topoSort(i, adj, vis, st);
    }
    st.push(curr);
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    vector<V> edges = {{2, 3}, {3, 1}, {4, 0}, {4, 1}, {5, 0}, {5, 2}};
    int n = 6;
    stack<int> st;
    vector<bool> vis(n, false);
    vector<V> adj(n);
    for (auto i : edges){
        adj[i[0]].push_back(i[1]);
    }

    for (int i = 0 ; i < n ; i++){
        if (!vis[i]) topoSort(i, adj, vis, st);
    }

    V ans;
    while (!st.empty()){
        ans.push_back(st.top());
        st.pop();
    }
    for (auto i : ans) cout << i << ' ';
}
