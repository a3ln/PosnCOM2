// 49 by gemini
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

int solve(int index, int tools, const vector<int>& houseValues, map<pair<int, int>, int>& memo) {
    if (index < 0) {
        return 0;
    }

    if (memo.find({index, tools}) != memo.end()) {
        return memo[{index, tools}];
    }

    int result = 0;

    // Case 1: Don't use a tool, steal from current house
    result = max(result, houseValues[index] + solve(index - 2, tools, houseValues, memo));

    // Case 2: Don't steal from current house
    result = max(result, solve(index - 1, tools, houseValues, memo));

    // Case 3: Use a tool
    if (tools > 0 && index > 0) {
        result = max(result, houseValues[index] + houseValues[index - 1] + solve(index - 3, tools - 1, houseValues, memo));
    }

    memo[{index, tools}] = result;
    return result;
}

int main() {
    int numTools = 4;
    vector<int> houseValues = {1, 2, 3, 1, 5, 6, 7, 8, 9};
    int numHouses = houseValues.size();

    if (numHouses == 0) {
        cout << 0 << endl;
        return 0;
    }

    map<pair<int, int>, int> memo;
    int maxCheese = solve(numHouses - 1, numTools, houseValues, memo);

    cout << maxCheese << endl;

    return 0;
}