// 41
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    vector<double> info;
    int cnt = 0;
    while (true) {
        char c;
        cin >> c;
        if (c == 'x') break;
        if (c == 'i') {
            double n;
            cin >> n;
            info.push_back(n);
        } else {
            double n;
            cin >> n;
            auto it = lower_bound(info.begin(), info.end(), n);
            if (it != info.end()) cnt++;
        }
    }

    cout << cnt;
}

/*q 1
i 1.97
i 1.98
i 1.99
i 1.99
q 2
x*/