#include<bits/stdc++.h>
using namespace std;

int Partition(vector<int> &nums, int l, int r){
    int piv = nums[r];
    int i = l-1;

    for (int j = l ; j <= r-1 ; j++){
        if (nums[j]<piv){
            i++;
            swap(nums[i], nums[j]);
        }
    }

    swap(nums[i+1], nums[r]);
    return i+1;
}

void quickSort(vector<int> &nums, int l, int r){
    if (l<r){
        int piv = Partition(nums, l, r);

        quickSort(nums, l, piv-1);
        quickSort(nums, piv+1, r);
    }
}

int main(){
    vector<int> nums = {10, 7, 8, 9, 1, 5};
    int n = nums.size();
    quickSort(nums, 0, n-1);

    for (auto i : nums) cout << i << " ";
}
