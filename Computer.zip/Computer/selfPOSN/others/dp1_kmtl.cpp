// 37
#include<bits/stdc++.h>
using namespace std;

int a, b, c;
vector<int> dp;
int ribbon(int n) {
    if (n == 0) return 0;
    if (n < 0) return INT_MIN;

    if (dp[n] != INT_MIN) return dp[n];

    int maxa = ribbon(n-a)+1;
    int maxb = ribbon(n-b)+1;
    int maxc = ribbon(n-c)+1;

    int maxx = max(maxa, max(maxb, maxc));
    dp[n] = max(dp[n], maxx);

    return maxx;
}

int main() {
    int n;
    cin >> n >> a >> b >> c;
    dp.resize(n+1, INT_MIN);

    cout << ribbon(n);
}