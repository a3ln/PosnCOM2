#include<iostream>
#include<vector>
using namespace std;

#define V vector<int>

int knapSack(V &val, V &wt, int w){
    V dp(w+1, 0);

    for (int i = 1 ; i <= wt.size() ; i++){
        for (int j = w ; j >= wt[i-1] ; j--){
            dp[j] = max(dp[j], dp[j - wt[i - 1]] + val[i - 1]);
        }
    }
    return dp[w];
}

int knapSackRec(V &val, V &wt, int w, int n, vector<V> &memo){
    if (n == 0 || w == 0) return 0;
    if (memo[n][w]!=-1) return memo[n][w];

    int pick = 0;
    if (wt[n-1]<=w) pick = val[n-1] + knapSackRec(val, wt, w-wt[n-1], n-1, memo);

    int not_pick = knapSackRec(val, wt, w, n-1, memo);

    return memo[n][w] = max(pick, not_pick);
}

int main(){
    V val = {1, 2, 3};
    V wt = {4, 5, 1};
    int W = 4;

    int n = val.size();
    vector<V> memo(n+1, V(W+1, -1));

    cout << knapSackRec(val, wt, W, n, memo);
}
