// 39
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    if (n == 1) return info[0];

    vector<int> dp(n, 0);
    dp[0] = info[0];
    dp[1] = max(info[0], info[1]);

    for (int i = 2 ; i < n ; i++) {
        dp[i] = max(dp[i-1], dp[i-2]+info[i]);
    }

    cout << dp[n-1];
}