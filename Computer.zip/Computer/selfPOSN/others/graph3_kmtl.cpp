// 43
#include<bits/stdc++.h>
using namespace std;

vector<pair<int, int>> dis = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
vector<vector<bool>> visited;
vector<string> info;
int n, m;

int dfs(int i, int j) {
    int c = 1;
    visited[i][j] = true;

    for (auto d : dis) {
        int x = i + d.first;
        int y = j + d.second;

        if (x>=0 && y>=0 && x<n && y<m && info[x][y] == '0' && !visited[x][y]) {
            c+=dfs(x, y);
        }
    }

    return c;
}

int main() {
    int ans = 0;
    cin >> n >> m;
    info.resize(n);
    visited.resize(n, vector<bool>(m, false));
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    for (int i = 0 ; i < n ; i++) {
        for (int j = 0 ; j < m ; j++) {
            if (info[i][j] == '0' && !visited[i][j]) {
                ans = max(ans, dfs(i, j));
            }
        }
    }
    cout << ans;
}

/*10 10
.0......00
.00....000
..00...000
...0...000
...0..0...
.....000..
...0...00.
..000.....
.00000000.
....0000..*/