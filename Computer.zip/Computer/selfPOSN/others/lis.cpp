// 54
#include<bits/stdc++.h>
using namespace std;

int main() {
    vector<int> info = { 10, 22, 9, 33, 21, 50, 41, 60 };

    int n = info.size();
    vector<int> dp(n, 1);
    for (int i = 1 ; i < n ; i++) {
        for (int prev = 0 ; prev < i ; prev++) {
            if (info[i]>info[prev] && dp[i]<dp[prev]+1) {
                dp[i] = dp[prev]+1;
            }
        }
    }

    cout << *max_element(dp.begin(), dp.end());
}