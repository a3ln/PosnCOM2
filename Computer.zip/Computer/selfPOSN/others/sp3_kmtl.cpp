// 50
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<vector<int>> path(1e3+1);
    for (int i = 0 ; i < n ; i++) {
        int u, v;
        cin >> u >> v;
        path[u].push_back(v);
        path[v].push_back(u);
    }

    vector<int> dis(1e3+1, INT_MAX);
    vector<bool> visited(1e3+1, false);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    dis[0] = 0;
    pq.push({0, 0});
    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (u == 1000) {
            cout << dis[u];
            return 0;
        }
        if (visited[u]) continue;
        visited[u] = true;

        for (auto v : path[u]) {
            if (dis[v]>dis[u]+1 && !visited[v]) {
                dis[v] = dis[u]+1;
                pq.push({dis[v], v});
            }
        }
    }
}