//31
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> ans;
    for (int i = 0 ; i < n ; i++) {
        int a;
        cin >> a;

        int c = 0;
        while (a!=0) {
            if (a%2==0) a/=2;
            else a-=1;
            c++;
        }
        ans.push_back(c);
    }

    for (auto i : ans) cout << i << "\n";
}