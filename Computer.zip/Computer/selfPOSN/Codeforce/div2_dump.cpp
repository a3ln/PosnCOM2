// 86
#include <bits/stdc++.h>
using namespace std;

int main() {
    int q;
    cin >> q;
    while (q--) {
        int n, a, b;
        cin >> n >> a >> b;
        bool a_sat = false, b_sat = false;
        if (n%a==0 && a<=ceil(n/2.0)) {
            a_sat = true;
        } else if (ceil(n/2.0)==a) {
            a_sat = true;
        }
        if (n%b==0 && b<=ceil(n/2.0)) {
            b_sat = true;
        } else if (ceil(n/2.0)==b) {
            b_sat = true;
        }

        if (a_sat && b_sat) cout << "yes" << "\n";
        else cout << "no" << "\n";
    }
}