#include<bits/stdc++.h>
using namespace std;

#define int long long
int n, m, k;
vector<int> tim;
vector<int> ti;
bool check(int mid) {
    int sum = 0;
    for (int i = 0 ; i < n ; i++) {
        if (ti[i]>mid) return false;
        sum+=mid/ti[i];
    }
    return sum>=k;
}

int32_t main() {
    cin >> n >> m >> k;
    tim.resize(n);
    int minn = INT_MAX;
    for (int i = 0 ; i < n ; i++) {
        cin >> tim[i];
        minn = min(minn, tim[i]);
    }
    sort(tim.begin(), tim.end());
    if (n!=m) {
        ti.resize(m);
        for (int i = 0 ; i < m ; i++) {
            ti[i] = tim[i];
        }
    } else {
        ti = tim;
    }

    int l = minn;
    int r = minn*k;
    while (l < r) {
        int mid = (l+r)/2;
        if (check(mid)) {
            r = mid; //decrease mid
        } else {
            l = mid+1; //increase mid
        }
    }
    cout << l;
}