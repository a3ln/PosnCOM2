// 57
#include<bits/stdc++.h>
using namespace std;

void trial_problem() {
    int n;
    cin >> n;
    while (n--) {
        int a, b;
        cin >> a >> b;
        cout << a+b << "\n";
    }
}

void easy_problem() {
    int n;
    cin >> n;
    while (n--) {
        int a;
        cin >> a;
        cout << a-1 << "\n";
    }
}

void hard_problem() {
    int n;
    cin >> n;
    while (n--) {
        int m, a, b, c;
        cin >> m >> a >> b >> c;
        int ans = 0;
        if (m<=a) ans+=m;
        else ans+=a;
        if (m<=b) ans+=m;
        else ans+=b;

        if (ans<=m*2) ans+=c;
        else {
            cout << ans << "\n";
            return;
        }

        if (ans>m*2) cout << m*2 << "\n";
        else cout << ans << "\n";
    }
}

void short_sort() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        bool t = false;
        for (int i = 0 ; i < s.size() ; i++) {
            for (int j = 0 ; j < s.size() ; j++) {
                // if (i == j) break;
                string temp = s;
                swap(temp[i], temp[j]);
                if (temp == "abc") {
                    cout << "YES\n";
                    t = true;
                    break;
                }
            }
            if (t) break;
        }
        if (!t) cout << "NO\n";
    }
}

void vlad_ans_the_best_of_five() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        int a = 0, b = 0;
        for (int i = 0 ; i < 5 ; i++) {
            if (s[i]=='A') a++;
            else b++;
        }
        if (a>b) cout << "A\n";
        else cout << "B\n";
    }
}

void lucky() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        int l = 0, r = 0;
        for (int i = 0 ; i < 3 ; i++) {
            l+=s[i]-'0';
            r+=s[6-i-1]-'0';
        }
        // cout << l << " " << r << "\n";
        l==r ? cout << "YES\n" : cout << "NO\n";
    }
}

void marathon() {
    int n;
    cin >> n;
    while (n--) {
        int t, a[3];
        cin >> t >> a[0] >> a[1] >> a[2];
        int c = 0;
        for (int i = 0 ; i < 3 ; i++) {
            if (a[i]>t) c++;
        }
        cout << c << "\n";
    }
}

void spell_check() {
    int n;
    cin >> n;
    while (n--) {
        int ns;
        cin >> ns;
        string s;
        cin >> s;
        if (ns!=5) {
            cout << "NO\n";
            continue;
        }
        string cot = "Timur";
        unordered_map<char, int> give, corr;
        for (auto i : s) give[i]++;
        for (auto i : cot) corr[i]++;

        if (give == corr) cout << "YES\n";
        else cout << "NO\n";
    }
}

void colourblindness() {
    int n;
    cin >> n;
    while (n--) {
        int l;
        cin >> l;
        string s1, s2;
        cin >> s1 >> s2;
        for (int i = 0 ; i < l ; i++) {
            if (s1[i]=='G') s1[i] = 'B';
            if (s2[i]=='G') s2[i] = 'B';
        }

        if (s1 == s2) cout << "YES\n";
        else cout << "NO\n";
    }
}

void creating_words() {
    int n;
    cin >> n;
    while (n--) {
        string s1, s2;
        cin >> s1 >> s2;
        swap(s1[0], s2[0]);
        cout << s1 << " " << s2 << "\n";
    }
}

void normal_problem() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        for (int i = 0 ; i < s.size() ; i++) {
            if (s[i]=='p') s[i] = 'q';
            else if (s[i]=='q') s[i] = 'p';
        }
        reverse(s.begin(), s.end());
        cout << s << "\n";
    }
}

void skibidus_ans_among_u() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        int m = s.size();
        s.erase(s.end()-1);
        s.erase(s.end()-1);
        s.push_back('i');
        cout << s << "\n";
    }
}

void my_first_sorting_problem() {
    int n;
    cin >> n;
    while (n--) {
        int a, b;
        cin >> a >> b;
        cout << min(a, b) << " " << max(a, b) << "\n";
    }
}

void different_string() {
    int n;
    cin >> n;
    while (n--) {
        string s;
        cin >> s;
        int m = s.size();
        bool t = true;
        for (int i = 0 ; i < m ; i++) {
            for (int j = 0 ; j < m ; j++) {
                if (s[i] != s[j]) {
                    t = false;
                    swap(s[i], s[j]);
                    cout << "YES\n" << s << "\n";
                    break;
                }
            }
            if (!t) break;
        }
        if (t) cout << "NO\n";
    }
}

void stair_prak_or_neither() {
    int n;
    cin >> n;
    while (n--) {
        int a, b, c;
        cin >> a >> b >> c;
        if (a<b && b<c) cout << "STAIR\n";
        else if (a<b && b>c) cout << "PEAK\n";
        else cout << "NONE\n";
    }
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    // trial_problem();
    // easy_problem();
    // hard_problem();
    // short_sort();
    // vlad_ans_the_best_of_five();
    // lucky();
    // marathon();
    // spell_check();
    // colourblindness();
    // creating_words();
    // normal_problem();
    // skibidus_ans_among_u();
    // my_first_sorting_problem();
    // different_string();
    // stair_prak_or_neither();
}