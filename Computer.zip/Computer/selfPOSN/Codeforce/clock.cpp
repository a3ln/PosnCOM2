#include<bits/stdc++.h>
using namespace std;

int found(string &b) {
    string temp1;
    string temp2;
    for (int i = 0 ; i < 2 ; i++) {
        temp1.push_back(b[i]);
    }
    for (int i = 3 ; i < 5 ; i++) {
        temp2.push_back(b[i]);
    }

    int h = stoi(temp1);
    int m = stoi(temp2);

    h*=30;
    m*=6;

    int ans = abs(m-h);
    if (ans>=180) {
        return ans;
    }
    return 360-ans;
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<pair<int, int>> ans;
    for (int i = 0 ; i < n ; i++) {
        int a;
        cin >> a;
        int maxx = INT_MIN;
        int index = 1;
        for (int j = 1 ; j <= a ; j++) {
            string b;
            cin >> b;
            int c = found(b);
            if (maxx<c) {
                maxx = c;
                index = j;
            }
        }
        ans.push_back({index, maxx});
    }

    for (auto i : ans) {
        cout << i.first << " " << i.second << "\n";
    }
}