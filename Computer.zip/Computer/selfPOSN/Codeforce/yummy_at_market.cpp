#include <bits/stdc++.h>
using namespace std;

int choose(vector<int> &store) {
    vector<int> lis;
    for (int num : store) {
        auto it = lower_bound(lis.begin(), lis.end(), num);
        // 2 3 7 8 10 -> 4 -> 2 3 [4] 8 10
        if (it == lis.end()) {
            lis.push_back(num);
        } else {
            *it = num;
        }
    }
    return lis.size();
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> store(n);
    for (int i = 0; i < n; i++) {
        cin >> store[i];
    }

    cout << choose(store) << '\n';
}