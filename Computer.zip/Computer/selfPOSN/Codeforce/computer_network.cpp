//34
#include<bits/stdc++.h>
using namespace std;
#define p pair<int, int>

int n;
int mst(vector<vector<int>> &path) {
    vector<bool> visited(n, false);
    priority_queue<p> pq;

    int sum = 0;
    pq.push({INT_MAX, 0});
    while(!pq.empty()) {
        int u = pq.top().second;
        int w = pq.top().first;
        pq.pop();

        if (visited[u]) continue;
        visited[u] = true;
        if (w!=INT_MAX) sum+=w;

        for (int i = 0 ; i < path[u].size() ; i++) {
            if (path[u][i] != -1 && !visited[i]) {
                pq.push({path[u][i], i});
            }
        }
    }

    return sum;
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n;
    vector<p> edge;
    vector<vector<int>> path(n, vector<int>(n, -1));
    for (int i = 0 ; i < n ; i++) {
        int x, y;
        cin >> x >> y;
        for (int j = 0 ; j < edge.size() ; j++) {
            int x1 = edge[j].first;
            int y1 = edge[j].second;
            int w = abs(x-x1)+abs(y-y1);
            path[i][j] = w;
            path[j][i] = w;
        }
        edge.push_back({x, y});
    }
    int m;
    cin >> m;
    for (int i = 0 ; i < m ; i++) {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        path[x][y] = INT_MAX;
        path[y][x] = INT_MAX;
    }

    cout << mst(path);
}