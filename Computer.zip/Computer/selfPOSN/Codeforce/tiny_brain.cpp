//33
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> num(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> num[i];
    }

    int minn = INT_MAX;
    sort(num.begin(), num.end());
    vector<int> a;
    vector<int> b;
    for (int i = 0 ; i < n ; i++) {
        a.push_back(num[i]);
        int suma = accumulate(a.begin(), a.end(), 0);
        int sumb = accumulate(b.begin(), b.end(), 0);
    }
}