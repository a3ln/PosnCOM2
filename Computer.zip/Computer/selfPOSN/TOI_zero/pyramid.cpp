// 68
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int l, n;
    cin >> l >> n;
    int i = 1;
    while (n>=0) {
        n-=i*i;
        i++;
        l--;
    }
    cout << ++l;
}