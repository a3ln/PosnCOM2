// 67
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, l;
    cin >> n >> l;
    vector<pair<int, int>> t;
    for (int i = 0 ; i < n ; i++) {
        int s, e;
        cin >> s >> e;
        t.push_back({s, e});
    }

    sort(t.begin(), t.end());
    int c = 1;
    bool temp = false;
    int s = t[0].first;
    int e = t[0].second;
    for (auto i : t) {
        if (!temp) {
            temp = true;
            continue;
        }
        int st = i.first;
        int en = i.second;
        if (st > e) {
            s = st;
            e = en;
            c++;
            continue;
        }

        if (st < s && en < e) e = en;
        else if (st > s && en < e) {
            s = st;
            e = en;
        } else if (st > s && en > e) s = st;
    }
    cout << c;
}