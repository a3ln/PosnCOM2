// 66
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    map<int, vector<vector<int>>> path_t;
    vector<vector<int>> path(n+1);
    while (m--) {
        int k;
        cin >> k;
        vector<int> temp;
        while (k--) {
            int a;
            cin >> a;
            temp.push_back(a);
        }
        int t;
        cin >> t;
        path_t[t].push_back(temp);
        for (auto i : temp) path[i].push_back(t);
    }

    int c = 0;
    vector<bool> lit(n+1, false);
    queue<int> q;
    q.push(1);
    while (!q.empty()) {
        int u = q.front();
        q.pop();

        if (lit[u]) continue;
        lit[u] = true;
        c++;
        for (auto v : path[u]) {
            for (auto ve : path_t[v]) {
                bool t = true;
                for (auto vec : ve) {
                    if (!lit[vec]) {
                        t = false;
                        break;
                    }
                }
                if (t) {
                    q.push(v);
                    break;
                }
            }
        }
    }

    cout << c;
}

/*5 4
1 1 2
1 1 3
2 2 4 5
1 3 5
*/