// 69
#include<bits/stdc++.h>
using namespace std;

int n;

void print(int m) {
    for (int i = 0 ; i < n ; i++) {
        for (int j = 0 ; j < n ; j++) {
            if (m+j<10) cout << "0";
            cout << m+j << " ";
        }
        m++;
        cout << "\n";
    }
}

int main() {
    cin >> n;
    int m = 1;
    while (m<=5) {
        print(m++);
    }
}

/*8 5 12 12 15 0 23 15 18 12 4*/

/*
01 02 03 04 05
02 03 04 05 06
03 04 05 06 07
04 05 06 07 08
05 06 07 08 09
02 03 04 05 06
 */