// 53
#include<bits/stdc++.h>
using namespace std;

#define int long long

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> inf(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> inf[i];
    }
    int ans = 0;
    for (int i = 1 ; i < n ; i++) {
        if (inf[i] > inf[i-1]) {
            ans+=inf[i]-inf[i-1];
        }
    }
    cout << ans;
}

/*5 6 2 3 7 4*/