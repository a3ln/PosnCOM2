// 62
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> info(301, 0);
    for (int i = 0 ; i < n ; i++) {
        int a;
        cin >> a;
        info[a]++;
    }

    cout << *max_element(info.begin(), info.end());
}