// 64
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> info(n, vector<int>(m));
    for (int i = 0 ; i < n ; i++) {
        for (int j = 0 ; j < m ; j++) {
            cin >> info[i][j];
        }
    }

    int ans = 0;
    for (int i = 0 ; i <= n-5 ; i++) {
        for (int j = 0 ; j <= m-5 ; j++) {
            set<int> t;
            for (int a = i ; a < i+5 ; a++) {
                for (int b = j ; b < j+5 ; b++) {
                    int temp = info[a][b];
                    t.insert(temp);
                }
            }
            if (t.size()>=5) ans++;
        }
    }

    cout << ans;
}