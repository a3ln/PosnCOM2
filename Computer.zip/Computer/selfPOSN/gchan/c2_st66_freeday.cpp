// 85
#include <bits/stdc++.h>
using namespace std;

int dp[1001]; // make the value in all = 0
int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    // vector<int> dp(1e3+1, 0);
    int minn = INT_MAX, maxx = INT_MIN;
    for (int i = 0 ; i < n ; i++) {
        int m;
        cin >> m;
        while(m--) {
            int a,b;
            cin >> a >> b;
            dp[a]++;
            dp[b]--;
            minn = min(minn, a);
            maxx = max(maxx, b);
        }
    }

    for (int i = 0 ; i <= 1000 ; i++) dp[i]+=dp[i-1];
    maxx--;
    vector<int> ans;
    for (int i = minn ; i <= maxx ; i++) {
        if (!dp[i] && dp[i-1]) ans.push_back(i); // 1 [0]
        else if (i != minn && dp[i] && !dp[i-1]) ans.push_back(i); // 0 [1]
    }

    if (ans.size() == 0) cout << -1;
    else for (auto i : ans) cout << i << " ";
}

/*3
2 1 2 5 6
1 1 3
1 4 10

1++ 2- 3- 4+ 5+ 6- 7 8 9 10-
*/