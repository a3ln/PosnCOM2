// 65
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    vector<int> diff(n);
    diff[0] = info[0];
    cout << diff[0];
    for (int i = 1 ; i < n ; i++) {
        diff[i] = info[i] - info[i-1];
        cout << " " << diff[i];
    }
    cout << "\n";

    int curr = diff[0];
    int ans = diff[0];
    for (int i = 1 ; i < n ; i++) {
        curr = max(curr+diff[i], diff[i]);
        ans = max(ans, curr);
    }
    cout << ans;
}

/*5
6 2 3 7 4*/