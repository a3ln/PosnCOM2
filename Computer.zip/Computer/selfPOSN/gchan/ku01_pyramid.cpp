// 60
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int l, n;
    cin >> l >> n;
    int c = 0, i = 1;
    while (n>0) {
        n-=i*i;
        // cout << n << "\n";
        i++;
        if (n>=0) c++;
    }

    cout << min(l-c, l);
    // cout << c;
}