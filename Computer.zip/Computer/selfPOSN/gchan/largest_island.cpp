// 51
#include<bits/stdc++.h>
using namespace std;

int n, m;
vector<pair<int, int>> dis = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
vector<string> mappu;

int bfs(int i, int j) {
    int c = 0;
    queue<pair<int, int>> q;
    q.push({i, j});
    while (!q.empty()) {
        int x = q.front().first;
        int y = q.front().second;
        q.pop();

        c++;
        for (auto d : dis) {
            int nx = x+d.first;
            int ny = y+d.second;

            if (nx>=0 && nx<n && ny>=0 && ny<m && mappu[nx][ny]=='1') {
                mappu[nx][ny] = '0';
                q.push({nx, ny});
            }
        }
    }
    return c;
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m;
    mappu.resize(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> mappu[i];
    }

    int ans = 0;
    for (int i = 0 ; i < n ; i++) {
        for (int j = 0 ; j < m ; j++) {
            if (mappu[i][j]=='1') {
                mappu[i][j] = '0';
                ans = max(ans, bfs(i, j));
            }
        }
    }
    cout << ans;
}

/*8 13 0010000100000 0000000111000 0110100000000 0100110010100 0100110011100 0000000000100 0000000111000 0000000110000*/