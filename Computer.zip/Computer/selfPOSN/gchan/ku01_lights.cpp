// 63
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    sort(info.begin(), info.end());
    int ans = 0;
    int count = 0;
    for (auto i : info) {
        count+=i;
        ans+=count*2;
    }

    cout << ans;
}