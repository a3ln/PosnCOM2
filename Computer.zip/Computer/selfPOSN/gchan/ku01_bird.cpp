// 61
#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> num(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> num[i];
    }

    int c = 0;
    for (int i = 0 ; i < n ; i++) {
        if (i == 0 && num[i+1]<num[i]) c++;
        else if (i == n-1 && num[i-1]<num[i]) c++;
        else if (num[i]>num[i-1] && num[i]>num[i+1]) c++;
    }

    cout << c;
}