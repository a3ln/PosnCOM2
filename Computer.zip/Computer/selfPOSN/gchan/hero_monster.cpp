// 52
#include<bits/stdc++.h>
using namespace std;

#define int long long

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m; // hero and monster number
    cin >> n >> m;
    vector<int> hero(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> hero[i];
    }

    vector<pair<int, int>> mon(m+1);
    for (int i = 0 ; i < m ; i++) {
        int p, c;
        cin >> p >> c;
        mon[i] = {p, c};
    }

    sort(mon.begin(), mon.end());
    vector<int> sum(m+1);
    sum[0] = mon[0].second;
    for (int i = 1 ; i <= m ; i++) {
        sum[i] = sum[i-1]+mon[i].second;
    }
    for (auto h : hero) {
        int ans = 0;
        auto it = upper_bound(mon.begin(), mon.end(), make_pair(h, LLONG_MAX));
        int index = it-mon.begin()-1;
        if (it == mon.end()) {
            index = m;
        }
        cout << sum[index] << "\n";
    }
}

/*4 5 1 4 2 6 1 2 1 3 5 4 2 5 3 6*/