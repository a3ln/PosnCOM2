#include<bits/stdc++.h>
using namespace std;

#define p pair<int, int>

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n ,m;
    cin >> n >> m;
    vector<vector<p>> path(n);
    for (int i = 0 ; i < m ; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        path[u].push_back({v, w});
        path[v].push_back({u, w});
    }
    int s, d, t;
    cin >> s >> d >> t;
    s--;
    d--;

    vector<int> dis(n, 0);
    priority_queue<p> pq;
    vector<bool> visited(n, false);
    dis[s] = INT_MAX;
    pq.push({dis[s], s});
    int ans;
    while (!pq.empty()) {
        int u = pq.top().second;
        int minn = pq.top().first;
        pq.pop();

        if (u == d) {
            ans = minn;
            break;
        }
        if (visited[u]) continue;
        visited[u] = true;
        for (auto i : path[u]) {
            int v = i.first;
            int w = i.second;
            int minnn = min(minn, w);
            if (minnn > dis[v] && !visited[v]) {
                dis[v] = minnn;
                pq.push({dis[v], v});
            }
        }
    }

    cout << ceil(double(t)/(ans-1));
}