#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    vector<int> in;
    in.push_back(INT_MIN);
    while (cin >> n) {
        in.push_back(n);
    }
    in.push_back(INT_MIN);

    vector<int> ans;
    for (int i = 0 ; i < in.size() ; i++) {
        if (in[i]>in[i-1] && in[i]>in[i+1]) {
            ans.push_back(in[i]);
        }
    }

    for (auto i : ans) {
        cout << i << " ";
    }
}