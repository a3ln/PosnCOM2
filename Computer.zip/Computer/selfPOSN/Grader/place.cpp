#include<bits/stdc++.h>
using namespace std;

#define p pair<int, int>

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<p>> path(n);
    for (int i = 0 ; i < m ; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        w--;
        path[u].push_back({v, w});
        path[v].push_back({u, w});
    }

    vector<bool> visited(n, false);
    priority_queue<p> pq;

    long long sum = 0;
    pq.push({0, 0});
    while (!pq.empty()) {
        int u = pq.top().second;
        int w = pq.top().first;
        pq.pop();

        if (visited[u]) continue;
        // cout << w << " ";
        visited[u] = true;
        sum+=w;
        for (auto i : path[u]) {
            int v = i.first;
            int w1 = i.second;
            if (!visited[v]) {
                pq.push({w1, v});
            }
        }
    }

    cout << sum;
}

/*6 9
1 2 8
2 3 6
1 4 6
4 2 6
4 5 8
2 5 7
5 6 5
2 6 9
3 6 5*/