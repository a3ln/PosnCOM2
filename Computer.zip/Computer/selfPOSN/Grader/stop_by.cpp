#include<bits/stdc++.h>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    cin.ignore();
    vector<pair<string, vector<int>>> data;

    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> count;
    for (int i = 0 ; i < n ; i++) {
        string line;
        getline(cin, line);
        istringstream iss(line);
        string name;
        iss >> name;

        vector<int> nums;
        int num;
        while(iss >> num) {
            nums.push_back(num);
        }
        data.push_back({name, nums});
        // cout << "*";
    }

    // for (const auto& entry : data) {
    //     cout << "Name: " << entry.first << "\nData: ";
    //     for (int n : entry.second) {
    //         cout << n << " ";
    //     }
    //     cout << endl;
    // }

    for (int i = 0 ; i < n ; i++) {
        vector<int> v = data[i].second;
        auto num = lower_bound(v.begin(), v.end(), k);
        if (*num == k) {
            count.push({num-v.begin(), data[i].first});
        }
    }

    if (count.empty()) {
        cout << "-1";
        return 0;
    }
    int s = count.size();
    for (int i = 0 ; i < min(3, s) ; i++) {
        cout << count.top().second << " ";
        count.pop();
    }
}

/*5 7
taohu 0 1 7 9
mafuyu 2 5
ccsleep 2 4 7 25
sira 1
iris 32 64 128*/