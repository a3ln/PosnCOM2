#include<bits/stdc++.h>
using namespace std;

vector<int> ans;
void convert(int n, int b) {
    int a = n%b;
    ans.push_back(a);
    n=floor(n/b);
    // cout << n << " ";
    if (n <= 0) return;
    convert(n, b);
}

int main() {
    int n, b;
    cin >> n >> b;
    convert(n, b);
    for (int i = ans.size()-1 ; i >=0 ; i--) {
        cout << ans[i];
    }
}