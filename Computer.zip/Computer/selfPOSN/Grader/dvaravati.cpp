#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    string s1, s2;
    cin >> s1 >> s2;

    // start at 1
    int n = s1.length();
    vector<vector<int>> dp(n+1, vector<int>(n+1, 0));
    for (int i = 1 ; i <= n ; i++) {
        for (int j = 1 ; j <= n ; j++) {
            if (s1[i-1]==s2[j-1]) {
                dp[i][j] = dp[i-1][j-1]+1;
            } else {
                dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
            }
        }
    }

    // x y
    // start at 0
    string ans;
    int i = n;
    int j = n;
    while (i > 0 && j > 0) {
        if (s1[i-1] == s2[j-1]) {
            ans.push_back(s1[i-1]);
            i--;
            j--;
        } else {
            if (dp[i-1][j] > dp[i][j-1]) {
                i--;
            } else {
                j--;
            }
        }
    }

    reverse(ans.begin(), ans.end());
    cout << ans << "\n" << dp[n][n] << "\n";
    if (dp[n][n]>ceil(double(n)/2)) {
        cout << "y";
    } else cout << "n";
}