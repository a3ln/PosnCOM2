#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int a;
    map<int, int> data;
    while(cin >> a) {
        data[a] = 0;
    }

    vector<int> ans(0);
    vector<int> old;
    for (auto i = data.begin() ; i != data.end() ; i++) {
        int num = i->first;
        if (old.empty() || num==old.back()+1) {
            old.push_back(num);
        } else {
            old = {num};
        }
        if (old.size()>ans.size()) {
            ans = old;
        }
    }

    for (auto i : ans) {
        cout << i << " ";
    }
}