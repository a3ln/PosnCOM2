//29
#include<bits/stdc++.h>
using namespace std;

#define int long long
int knapsack(int w, vector<int> &wt, vector<int> &val, int n) {
    if (n == 0 || w == 0) return 0;

    int pick = 0;
    if (wt[n-1]<=w) {
        pick = val[n-1] + knapsack(w-wt[n-1], wt, val, n-1);
    }

    int not_pick = knapsack(w, wt, val, n-1);

    return max(pick, not_pick);
}

int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, w;
    cin >> n >> w;
    vector<int> wt(n);
    vector<int> val(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> wt[i] >> val[i];
    }

    cout << knapsack(w, wt, val, n);
}