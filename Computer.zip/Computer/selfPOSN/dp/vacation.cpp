#include<bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<vector<int>> hap;
    for (int i = 0 ; i < n ; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        hap.push_back({a, b, c});
    }

    vector<vector<int>> dp(n, vector<int>(3));
    dp[0] = {hap[0][0], hap[0][1], hap[0][2]};
    for (int i = 1 ; i < n ; i++) {
        priority_queue<pair<int, int>> pq;
        pq.push({dp[i-1][0], 0});
        pq.push({dp[i-1][1], 1});
        pq.push({dp[i-1][2], 2});
        for (int j = 0 ; j < 3 ; j++) {
            auto temp = pq.top();
            if (pq.top().second == j) pq.pop();
            dp[i][j] = pq.top().first+hap[i][j];
            if (pq.size() != 3) pq.push(temp);
        }
    }

    int ans = INT_MIN;
    for (int i = 0 ; i < 3 ; i++) {
        ans = max(ans, dp[n-1][i]);
    }
    cout << ans;
}