#include<bits/stdc++.h>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    vector<int> dp(n);
    dp[0] = 0;
    for (int i = 1 ; i < n ; i++) {
        int minn = INT_MAX;
        for (int j = i-k ; j < i ; j++) {
            if (j>=0) {
                minn = min(minn, dp[j]+abs(info[i]-info[j]));
            }
        }
        dp[i] = minn;
    }

    cout << dp[n-1];
}