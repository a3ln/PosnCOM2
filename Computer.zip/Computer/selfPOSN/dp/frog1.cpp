#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++) {
        cin >> info[i];
    }

    vector<int> dp(n, 0);
    for (int i = 0 ; i < n ; i++) {
        int curr = abs(info[i-1] - info[i]);
        int curr2 = abs(info[i-2] - info[i]);

        if (i == 0) dp[i] = 0;
        else if (i == 1) dp[i] = curr;
        else dp[i] = min(dp[i-1]+curr, dp[i-2]+curr2);
    }

    cout << dp[n-1];
}