#include<bits/stdc++.h>
using namespace std;

#define int long long
int32_t main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, w;
    cin >> n >> w;
    vector<pair<int, int>> info(n);
    for (int i = 0 ; i < n ; i++) {
        int a, b;
        cin >> a >> b;
        info[i] = {a, b};
    }

    vector<int> dp(w+1, 0);
    for (int i = 1 ; i <= n ; i++) {
        for (int j = w ; j >= info[i-1].first ; j--) {
            dp[j] = max(dp[j], dp[j-info[i-1].first]+info[i-1].second);
        }
    }

    cout << dp[w];
}