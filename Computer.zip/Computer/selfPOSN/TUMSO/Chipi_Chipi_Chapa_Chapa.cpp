// 81
#include<bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    if (n == 1) cout << "Chipi Chipi";
    else if (n == 2) cout << "Chapa Chapa";
    else if (n == 3) cout << "Dubi Dubi";
    else if (n == 4) cout << "Daba Daba";
    else if (n == 25) cout << "asahina senpai, wonderhoy";
    else if (n == 1983) cout << "is that the bite of 87";
    else if (n == 1987) cout << "freddy fazbear";
    else cout << "CEO entrepreneur";
}