// 58
#include<bits/stdc++.h>
using namespace std;

vector<pair<int, int>> dis = {{-1, 0}, {0, 1}, {1, 0}, {0, -1},
                                {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};

bool walk(vector<string> &path, int x, int y, vector<vector<bool>> &vis, bool ans, int c) {
    if (x == 0 && y == 7) {
        return true;
    }

    vector<string> temp = path;
    if (c!=0) {
        for (int i = 0 ; i < 8 ; i++) {
            for (int j = 0 ; j < 8 ; j++) {
                if (i+c>=8 && path[i][j] == 'S') {
                    // cout << c;
                    temp[i][j] = '.';
                }
                else if (path[i][j] == 'S') swap(temp[i][j], temp[i+c][j]);
            }
            // cout << temp[i] << "\n";
        }
        // cout << "\n";
    }

    vis[x][y] = true;

    for (auto d : dis) {
        int nx = x+d.first;
        int ny = y+d.second;

        if (nx>=0 && nx<8 && ny>=0 && ny<8 && temp[nx][ny]!='S' && temp[x][y]!='S' && !vis[nx][ny]) ans = ans || walk(path, nx, ny, vis, ans, c+1);
    }

    return ans;
}

void solve() {
    vector<string> path(8);
    vector<vector<bool>> vis(8, vector<bool>(8, false));
    for (int i = 0 ; i < 8 ; i++) {
        cin >> path[i];
    }
    path[7][0] = '.';
    path[0][7] = '.';
    // cout << path[7][1];

    bool ans = false;
    if (walk(path, 7, 0, vis, ans, 0)) cout << "WIN";
    else cout << "LOSE";
}

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    // cin >> n;
    n = 1;
    while (n--) {
        solve();
    }
}

/*
.......A
........
........
........
........
........
SS......
M.......
*/