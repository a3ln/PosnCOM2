#include<bits/stdc++.h>
using namespace std;

int change(string &base, int l, int n){
    for (int i = n ; i < base.length() ; i++){
        if (i == base.length()-1) base[i] = '0';
        else base[i] = base[i+1];
    }
    return l-1;
}

int main(){
    int m;
    cin >> m;
    string base, want;
    cin >> base >> want;

    int ans;
    int l = base.length();
    if (m == 0){
        for (int i = 0 ; i < want.length() ; i++){
            for (int j = 0 ; j<base.length() ;j++){
                if (want[i]==base[j]){
                    ans+=j+1;
                    base[j] = '0';
                    break;
                }
            }
        }
    } else {
        for (int i = 0 ; i< want.length() ; i++){
            for (int j = 0 ; j < l;j++){
                if (want[i]==base[j]){
                    ans+=j+1;
                    l = change(base, l, j);
                    break;
                }
            }
        }
    }

    cout << ans-1 << endl;
}