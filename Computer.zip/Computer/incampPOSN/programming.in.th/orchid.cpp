#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> height;
    for (int i = 0 ; i < n ; i++){
        int h;
        cin >> h;
        auto it = upper_bound(height.begin(), height.end(), h);
        if (it == height.end()){
            height.push_back(h);
        } else {
            int index = it - height.begin();
            height[index] = h;
        }
    }

    cout << n-height.size();
}

/*10
1
2
3
4
5
6
7
1
2
3*/