#include<bits/stdc++.h>
using namespace std;

int n;
vector<int> info;
vector<int> kadane(){
    int sum = 0;
    int curr = info[0];
    int res = info[0];
    int x = 0, y = 0, temp = 0;
    for (int i = 1 ; i < n ; i++){
        if (info[i]<curr+info[i]){
            curr = curr+info[i];
        } else {
            curr = info[i];
            temp = i;
        }

        if (res<curr){
            res = curr;
            x = temp;
            y = i;
        }
    }
    return {x, y, res};
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n;
    info.resize(n);
    for (int i = 0 ; i < n ; i++){
        cin >> info[i];
    }

    vector<int> ans = kadane();
    if (ans[2]<=0) {
        cout << "Empty sequence";
        return 0;
    } else{
        // cout << ans[0] << ans[1] << "\n";
        for (int i = ans[0] ; i <= ans[1] ; i++){
            cout << info[i] << " ";
        }
    }
    cout << "\n" << ans[2];
}

/*12
4 -6 3 -2 6 -4 -6 6 -6 4 -2 5*/