#include<bits/stdc++.h>
using namespace std;

int n, m;
vector<string> info;
vector<vector<bool>> visited;
vector<pair<int, int>> dis = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};
void bfs(int x, int y){
    queue<pair<int, int>> q;
    q.push({x, y});

    while (!q.empty()){
        int xu = q.front().first;
        int yu = q.front().second;
        q.pop();

        if (visited[xu][yu]) continue;
        visited[xu][yu] = true;

        for (auto d : dis){
            int xN = xu+d.first;
            int yN = yu+d.second;

            if (xN>=0 && xN<n && yN>=0 && yN<m && !visited[xN][yN] && info[xN][yN] == '1'){
                q.push({xN, yN});
            }
        }
    }
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m;
    info.resize(n);
    for (int i = 0 ; i < n ; i++){
        cin >> info[i];
    }

    int c = 0;
    visited.resize(n, vector<bool>(m, false));
    for (int i = 0 ; i < n ; i++){
        for (int j = 0 ; j < m ; j++){
            if (!visited[i][j] && info[i][j] == '1'){
                bfs(i, j);
                c++;
            }
        }
    }

    cout << c;
}
/*4 5
10011
00001
01100
10011*/