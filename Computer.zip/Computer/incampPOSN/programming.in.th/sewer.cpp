#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<char>> info(n,vector<char>(m));
    for (int i = 0 ; i < n ; i++){
        for (int j = 0 ; j < m ; j++){
            cin >> info[i][j];
        }
    }

    vector<pair<int, int>> move = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
    // N [0] | E [1] | S [2] | W [3]
    vector<vector<bool>> visited(n, vector<bool>(m, false));
    queue<pair<int, pair<int, int>>> q;
    q.push({1, {0, 0}});
    while (!q.empty()){
        int iu = q.front().second.first;
        int ju = q.front().second.second;
        int t = q.front().first;
        q.pop();

        if (visited[iu][ju]){
            cout << t << "\n" << iu+1 << " " << ju+1;
            return 0;
        }
        visited[iu][ju] = true;
        
        // N
        int iN = iu+move[0].first;
        int jN = ju+move[0].second;
        if (iN>=0 && !visited[iN][jN] && (info[iu-1][ju] == 'D' || info[iu-1][ju] == 'B')){
            q.push({t+1, {iN, jN}});
        }

        // E
        int iE = iu+move[1].first;
        int jE = ju+move[1].second;
        if (jE<m && !visited[iE][jE] && (info[iu][ju] == 'R' || info[iu][ju] == 'B')){
            q.push({t+1, {iE, jE}});
        }

        // S
        int iS = iu+move[2].first;
        int jS = ju+move[2].second;
        if (iS<n && !visited[iS][jS] && (info[iu][ju] == 'D' || info[iu][ju] == 'B')){
            q.push({t+1, {iS, jS}});
        }

        // W
        int iW = iu+move[3].first;
        int jW = ju+move[3].second;
        if (jW>=0 && !visited[iW][jW] && (info[iu][ju-1] == 'R' || info[iu][ju-1] == 'B')){
            q.push({t+1, {iW, jW}});
        }
    }
}