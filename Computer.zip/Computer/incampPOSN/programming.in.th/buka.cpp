#include<bits/stdc++.h>
using namespace std;

int main(){
    string a, b;
    char c;
    cin >> a >> c >> b;

    if (a.length()<b.length()){
        string temp;
        temp = a;
        a = b;
        b = temp;
    }
    if (c == '+'){
        if (a.length() == b.length()) a[0] = '2';
        else a[a.length()-b.length()] = '1';
    } else if (c=='*') {
        for (auto i : b){
            if (i == '0'){
                a.push_back(i);
            }
        }
    }

    cout << a << endl;
}