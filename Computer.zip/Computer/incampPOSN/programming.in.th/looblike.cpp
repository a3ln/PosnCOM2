#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;

    int max_num = 0;
    vector<int> a(10002, 0);
    for (int i = 0 ; i < n ; i++){
        int s;
        cin >> s;
        a[s]++;
        max_num = max(max_num, a[s]);
    }

    for (int i = 1 ; i<10002;i++){
        if (a[i] == max_num) cout << i << " ";
    }
}