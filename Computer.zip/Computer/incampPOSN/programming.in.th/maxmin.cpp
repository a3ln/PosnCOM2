#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    long Max = -2000000000;
    long Min = 2000000000;
    for (int i = 0 ; i < n ;i++){
        long a;
        cin >> a;
        Max = max(Max, a);
        Min = min(Min, a);
    }
    cout << Max << endl << Min;
}