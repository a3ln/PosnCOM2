#include<bits/stdc++.h>
using namespace std;

int add(priority_queue<int> pq, int a, int h){
    int sum = a;
    bool t = true;
    int c = 0;
    while (sum <= h){
        sum+=pq.top();
        c++;
        if (pq.top()==a && t){
            sum-=a;
            c--;
            t = false;
        }
        pq.pop();
    }
    return c;
}

int main(){
    int n;
    cin >> n;
    vector<int> a;
    priority_queue<int> pq;
    float h = 0;
    for (int i = 0 ; i<n;i++){
        int z;
        cin >> z;
        a.push_back(z);
        pq.push(z);
        h+=z;
    }

    h/=2.0;
    for (int i = 0;i<n;i++){
        int c = add(pq, a[i], h); 
        cout << c << endl;    
    }
}