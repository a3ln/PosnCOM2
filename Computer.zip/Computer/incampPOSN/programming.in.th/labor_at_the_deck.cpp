#include<bits/stdc++.h>
using namespace std;

#define int long long
bool check(vector<int> &labor, int t, int m){
    int sum = 0;
    for (int i = 0 ; i < labor.size() ; i++){
        int temp = t/labor[i];
        sum+=temp;
    }
    if (sum>=m) return true;
    return false;
}

int32_t main(){
    cin.tie(0)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    int maxx = INT_MIN;
    vector<int> labor(n);
    for (int i = 0 ; i < n ; i++){
        cin >> labor[i];
        maxx = max(maxx, labor[i]);
        
    }

    int l = 0, r = maxx*n;
    while (l<=r){
        int mid = (l+r)/2;
        if (check(labor, mid, m)){
            r = mid-1;
        } else{
            l = mid+1;
        }
    }

    cout << l;
}

/*2 5
7
12*/