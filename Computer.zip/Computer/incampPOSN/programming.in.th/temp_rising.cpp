#include<bits/stdc++.h>
using namespace std;

int maxx = -5;
int n;
vector<vector<bool>> visited;
vector<pair<int, int>> dis = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};

void walk(int x, int y, vector<vector<int>> &t){
    if (x < 0 || y < 0 || x >= n || y >= n) return;
    if (visited[x][y]) return;
    if (t[x][y]==100) return;

    visited[x][y] = true;
    maxx = max(maxx, t[x][y]);
    for (auto d : dis){
        int tx = x+d.first;
        int ty = y+d.second;
        if (tx>=0 && ty>=0 && tx<n && ty<n && t[tx][ty]>t[x][y]) walk(tx, ty, t);
    }
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n;
    int x, y;
    cin >> x >> y;
    vector<vector<int>> t(n, vector<int>(n));
    visited.resize(n, vector<bool>(n, false));
    for (int i = 0 ; i < n ; i++){
        for (int j = 0 ; j < n ; j++){
            cin >> t[i][j];
        }
    }

    walk(y-1, x-1, t);
    cout << maxx;
}

/*4
2 1
100 1 3 8
0 2 1 4
2 3 5 100
0 8 8 100

5
4 2
 0   1  100 100  0
100  2   3   1   1
100 100  4   5  100
 8  [7] 100  6  100
 7  100 100 100  9*/