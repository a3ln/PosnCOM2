#include<bits/stdc++.h>
using namespace std;

int main(){
    double x,y;
    cin >> x >> y;

    int ans = ceil(y/x);
    if (x>y) cout << 2;
    else cout << ans;
}