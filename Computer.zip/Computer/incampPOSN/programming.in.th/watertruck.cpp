#include<bits/stdc++.h>
using namespace std;

int main(){
    int m, n;
    cin >> m >> n;
    vector<vector<pair<int, int>>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        path[u].push_back({v, w});
        path[v].push_back({u, w});
    }

    
}