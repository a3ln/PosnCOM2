// 1 7 9
// 6 4 4
// 11-7 + 13-11 = 4+2 = 6
#include<bits/stdc++.h>
using namespace std;

bool comp(int a, int b){
    return a>b;
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> people(n);
    vector<int> base(n);
    for (int i = 0 ; i < n ; i++){
        cin >> people[i];
    }
    for (int i = 0 ; i < n ; i++){
        cin >> base[i];
    }

    sort(people.begin(), people.end());
    sort(base.begin(), base.end(), comp);

    vector<int> added(n);
    for (int i = 0 ; i < n ; i++) {
        added[i] = people[i]+base[i];
    }
    sort(added.begin(), added.end());

    int sum = 0;
    for (int i = 1 ; i < n ; i++){
        sum+=abs(added[i]-added[i-1]);
    }
    cout << sum;
}