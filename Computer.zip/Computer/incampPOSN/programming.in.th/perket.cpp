#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<pair<int, int>> ing;
    for (int i = 0 ; i < n ; i++){
        int a, b;
        cin >> a >> b;
        ing.push_back({a, b});
    }

    int min_diff = INT_MAX;
    for (int i= 0 ; i < n;i++){
        int s = ing[i].first, b = ing[i].second;
        if (abs(s-b)<min_diff){
            min_diff = abs(s-b);
        }
        for (int j = i+1 ; j < n ;j++){
            s*=ing[j].first;
            b+=ing[j].second;
            if (abs(s-b)<min_diff){
                min_diff = abs(s-b);
            }
        }
    }

    cout << min_diff;
}