#include<bits/stdc++.h>
using namespace std;

#define int long long

int m, n;
int grid(int i, int j, vector<vector<bool>> &path, vector<vector<int>> &dp){
    if (i<0 || j<0 || path[i][j]) return 0;
    if (i==0 && j==0) return 1;
    if (dp[i][j] != -1) return dp[i][j];

    dp[i][j] = grid(i-1, j, path, dp) + grid(i, j-1, path, dp);

    return dp[i][j];
}

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> m >> n;
    int nd;
    cin >> nd;
    vector<vector<bool>> path(n, vector<bool>(m, false));
    for (int i = 0 ; i < nd ; i++){
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        path[b][a] = true;
    }

    vector<vector<int>> dp(n, vector<int>(m, -1));
    cout << grid(n-1, m-1, path, dp);

    // for (int i = 1 ; i <= n ; i++){
    //     for (int j = 1 ; j <= m ; j++){
    //         if (path[i][j]) dp[i][j] = 0;
    //         else if (i==1 && j==1) dp[i][j] = 1;
    //         else dp[i][j] = dp[i-1][j]+dp[i][j-1];
    //     }
    // }

    // cout << dp[n][m];
}

/*5 4
3
2 2
2 3
4 2

6 5
3
5 4
2 2
1 4*/