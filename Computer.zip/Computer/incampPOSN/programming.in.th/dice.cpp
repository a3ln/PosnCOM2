#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<string> roll(n);
    for (int i = 0 ; i < n ; i++){
        cin >> roll[i];
    }

    for (auto i : roll){
        vector<int> dice = {1,2,3,5,4,6};
        for (auto j : i){
            vector<int> temp = dice;
            if (j == 'F'){
                dice[0] = temp[3];
                dice[1] = temp[0];
                dice[3] = temp[5];
                dice[5] = temp[1];
            } else if (j == 'B'){
                dice[0] = temp[1];
                dice[1] = temp[5];
                dice[3] = temp[0];
                dice[5] = temp[3];
            } else if (j == 'L'){
                dice[0] = temp[4];
                dice[2] = temp[0];
                dice[4] = temp[5];
                dice[5] = temp[2];
            } else if (j == 'R'){
                dice[0] = temp[2];
                dice[2] = temp[5];
                dice[4] = temp[0];
                dice[5] = temp[4];
            } else if (j == 'C'){
                dice[1] = temp[4];
                dice[2] = temp[1];
                dice[3] = temp[2];
                dice[4] = temp[3];
            } else if (j == 'D'){
                dice[1] = temp[2];
                dice[2] = temp[3];
                dice[3] = temp[4];
                dice[4] = temp[1];
            }
        }
        cout << dice[1] << " ";
    }
}