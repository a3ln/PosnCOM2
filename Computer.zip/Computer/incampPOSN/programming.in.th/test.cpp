#include<bits/stdc++.h>
using namespace std;

int find(vector<pair<int, int>> &v, int n){
    for (int i = 0 ; i < v.size() ; i++){
        if (v[i].second==n){
            return i;
        }
    }
}

int main(){
    int n_class, n_stu;
    cin >> n_class >> n_stu;
    vector<pair<int, int>> v;
    for (int i = 0 ; i < n_stu ; i++){
        int a, b;
        cin >> a >> b;
        v.push_back({a, b});
        // cout << "-";
    }
    priority_queue<pair<int, int>> ans;
    char a;
    int n;
    // cout << "s";
    vector<int> res;
    while(a != 'X'){
        cin >> a;
        // cout << "*";
        if (a == 'E'){
            cin >> n;
            int p = find(v, n);
            ans.push(v[p]);
        } else if(a == 'D'){
            res.push_back(ans.top().second);
            ans.pop();
        } else if (a == 'X'){
            break;
        }
    }

    for (auto i : res){
        cout << i << endl;
    }
    cout << 0;
}