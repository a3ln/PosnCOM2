#include<bits/stdc++.h>
using namespace std;

int main(){
    int n, m;
    cin >> n >> m;
    // start at 1
    map<int, int> info;
    for (int i = 0 ; i < m ; i++){
        int a, b;
        cin >> a >> b;
        a--;
        info[b] = a;
    }

    // keep them seperate in class and student
    vector<int> ans;
    vector<queue<int>> q(n);
    queue<int> qq; //keep the class
    while (1){
        char com;
        cin >> com;
        if (com == 'X') break;
        else if (com == 'E'){
            int a;
            cin >> a;
            if (q[info[a]].empty()){
                qq.push(info[a]);
            }
            q[info[a]].push(a);
        } else if (com == 'D'){
            if (qq.empty()) ans.push_back(-1);
            else {
                ans.push_back(q[qq.front()].front());
                q[qq.front()].pop();
                if (q[qq.front()].empty()) qq.pop();
            }
        }
    }

    for (auto i : ans){
        if (i == -1) cout << "empty\n";
        else cout << i << "\n";
    }
    cout << 0 << "\n";
}

/*2 6
1 41
1 42
1 43
2 201
2 202
2 203
E 41
E 201
D
E 202
E 42
E 43
D
E 203
D
D
D
X*/