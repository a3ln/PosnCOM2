#include<bits/stdc++.h>
using namespace std;

int main(){
    int r,p,s;
    /*r - p
    p - s
    s - r*/
    cin >> r >> p >> s;
    bool t = false;
    int Max = max(r,p);
    int MAX = max(Max, s);
    if ((r==MAX && p==MAX) || (r==MAX && s==MAX) || (s==MAX && p==MAX)){
        t = true;
    }
    if (r+p+s == 100) {
        if (t) cout << "I DON'T KNOW";
        else if (MAX == r) cout << "PAPER";
        else if (MAX == p) cout << "SCISSORS";
        else if (MAX == s) cout << "ROCK";
    } else {
        cout << "BUG";
    }
}