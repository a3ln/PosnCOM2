#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<string> a;
    for (int i = 0 ; i < n ; i++){
        string s;
        cin >> s;
        a.push_back(s);
    }

    vector<string> ans;

    for (auto i : a){
        stack<char> res;
        int t = 0;
        for (auto j : i){
            if (j == '(' || j == '[' || j == '{'){
                res.push(j);
            } else if (j == ')' || j == ']' || j == '}'){
                if (res.empty()) {
                    ans.push_back("no");
                    t = 1;
                    break;
                }
                else if ((j == ')' && res.top() == '(') || (j == ']' && res.top() == '[') || (j == '}' && res.top() == '{')) res.pop();
                else {
                    ans.push_back("no");
                    t = 1;
                    break;
                }
            }
        }
        if (res.empty() && t == 0) ans.push_back("yes");
        else if (!res.empty() && t == 0) ans.push_back("no");
    }

    for (auto i : ans){
        cout << i << endl;
    }
}