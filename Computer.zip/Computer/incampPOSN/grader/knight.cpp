#include<bits/stdc++.h>
using namespace std;

// start at (1, 1)
int n, m;
vector<vector<int>> health;
bool check(int mid){
    vector<vector<int>> dp(n+1, vector<int>(m+1 , INT_MIN));
    dp[n][m] = mid;
    for (int i = n ; i >= 1 ; i--){
        for (int j = m ; j >= 1 ; j--){
            if (i == n && j == m) continue;
            int curr = max(health[i][j+1], health[i+1][j])-health[i][j];
            if (curr > 0){
                dp[i][j] = curr;
            }
        }
    }
    return dp[1][1] > 0;
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n >> m;
    health.resize(n+2, vector<int>(m+2, INT_MIN));
    int minn = INT_MAX;
    for (int i = 1 ; i <= n ; i++){
        for (int j = 1 ; j <= m ; j++){
            cin >> health[i][j];
            minn = min(minn, health[i][j]);
        }
    }
    health[n+1][m] = health[n][m+1] = INT_MIN;

    int l;
    if (minn<=0) l = 1-minn;
    else l = 1;
    int r = l*n*m;

    while (l < r){
        int mid = l+(r-l)/2;
        if (check(mid)){
            r = mid; //decrease
        } else {
            l = mid+1; //increase
        }
    }

    cout << l;
}