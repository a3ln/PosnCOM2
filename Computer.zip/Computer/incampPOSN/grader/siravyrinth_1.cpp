#include<bits/stdc++.h>
using namespace std;

void walk(vector<string> &path, string &curr, string &minn, int x, int y){
    if (x < 0 || y < 0 || x > path[0].size()-1 || y > path.size()-1){
        if (minn.size()>curr.size()){
            minn = curr;
        }
        return;
    }

    if (path[x-1][y] != '#'){
        curr.push_back('L');
        walk(path, curr, minn, x-1, y);
    }
    if (path[x][y-1] != '#'){
        curr.push_back('U');
        walk(path, curr, minn, x, y-1);
    }
    if (path[x+1][y] != '#'){
        curr.push_back('R');
        walk(path, curr, minn, x+1, y);
    }
    if (path[x][y+1] != '#'){
        curr.push_back('D');
        walk(path, curr, minn, x, y+1);
    }

    curr.pop_back();
}

int main(){
    int n, m;
    cin >> n >> m;
    vector<string> path(n);
    int x, y;
    for (int i = 0 ; i < n ; i++){
        cin >> path[i];
        for (int j = 0 ; j < m ; j++){
            if (path[i][j]=='S'){
                x = j;
                y = i;
            }
        }
    }
    string curr, minn = "";
    walk(path, curr, minn, x, y);
    cout << minn;
}