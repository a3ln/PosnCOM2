#include<bits/stdc++.h>
using namespace std;

void add_edge(int u, int v, vector<vector<int>> &path){
    path[u].push_back(v);
    path[v].push_back(u);
}

void bfs(vector<vector<int>> &path, int n){
    vector<int> dis(n+1, INT_MAX);
    queue<int> q;
    
    q.push(0);
    dis[0] = 0;
    printf("%d(%d) -> ", 0, 0);
    while (!q.empty()){
        int u = q.front();
        q.pop();

        for (auto v : path[u]){
            if (dis[v] == INT_MAX){
                dis[v] = dis[u]+1;
                printf("%d(%d) -> ", v, dis[v]);
                q.push(v);
            }
        }
    }

}

void dfs(vector<vector<int>> &path, int n, vector<bool> &visited, int u){
    if (visited[u]) return;
    printf("%d -> ", u);
    visited[u] = true;
    for (auto v : path[u]){
        if (!visited[v]){
            dfs(path, n, visited, v);
        }
    }
}

int main(){
    int n, m;
    cin >> n >> m;
    vector<vector<int>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v;
        cin >> u >> v;
        add_edge(u, v, path);
    }

    // bfs(path, n);

    vector<bool> visited(n, false);
    dfs(path, n, visited, 0);
}

/*9 8
0 1
1 2
1 3
2 3
3 4
2 7
7 6
6 8*/