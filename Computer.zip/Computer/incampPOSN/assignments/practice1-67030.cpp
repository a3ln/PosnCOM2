#include<bits/stdc++.h>
using namespace std;

// O(log n)
int bsearch(vector<int> &v, int start, int end){
    if (start>end) return -1;
    int mid = (start+end)/2;
    if (mid==v[mid]) return mid;
    if (mid<v[mid]){
        return bsearch(v, start, mid-1);
    }
    return bsearch(v, mid+1, end);
}

int main(){
    vector<int> v = {0 ,-4 ,-3 ,-1 ,0 ,1 ,2 ,6 ,8 ,11 ,13 ,14 ,19 ,20 ,24 ,26 ,35 ,48 ,49 ,80 ,90 ,92};

    cout << bsearch(v, 0, v.size()-1) << endl;
}