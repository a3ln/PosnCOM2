#include<bits/stdc++.h>
using namespace std;

int resize(int **p, int n){
    int *temp = new int[n*2];
    for (int i = 0 ; i < n ; i++){
        temp[i] = (*p)[i]; //*p[i] is already pointer of array
    }
    delete []*p;
    *p = temp; //*p = x
    return n*=2;
}

int main(){
    int n = 4;
    int *x = new int[n];
    for (int i = 1 ; i <= n ; i++){
        x[i] = i;
    }
    n = resize(&x, n);
    cout << n << " : ";

    delete []x;
    return 0;
}