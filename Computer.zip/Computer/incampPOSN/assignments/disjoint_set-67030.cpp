#include<bits/stdc++.h>
using namespace std;

vector<int> p;
vector<int> r;
int find_parent(int i){
    if (p[i]==i) return i;
    return p[i] = find_parent(p[i]);
}

bool same(int i, int j){
    if (find_parent(i) == find_parent(j)) return true;
    return false;
}

void union_set(int i, int j){
    if (!same(i, j)){
        int x = find_parent(i);
        int y = find_parent(j);

        if (r[x] > r[y]){
            p[y] = x;
        } else if (r[x] == r[y]) {
            p[x] = y;
            r[y]++;
        } else {
            p[x] = y;
        }
    }
}

int main(){
    int n = 8;
    p = {0,1,2,3,4,5,6,7};
    r.resize(n, 0);

    union_set(0,1);
    union_set(2,3);
    union_set(4,5);
    union_set(6,7);
    
    union_set(0,2);
    union_set(4,6);

    union_set(0,4);

    for (int i = 0 ; i < n ; i++){
        cout << find_parent(i) << " ";
    }
}