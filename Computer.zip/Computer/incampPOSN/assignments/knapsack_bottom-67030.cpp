#include<bits/stdc++.h>
using namespace std;

int main(){
    int n, w;
    cin >> n >> w;
    vector<int> wt;
    vector<int> val;
    vector<vector<int>> dp;
    wt.resize(n);
    val.resize(n);
    dp.resize(n+1, vector<int>(w+1, 0));
    for (int i = 0 ; i < n ; i++){
        cin >> wt[i] >> val[i];
    }
    
    for (int i = 1 ; i <= n ; i++){
        for (int j = 1 ; j <= w ; j++){
            if (j<wt[i-1]){
                dp[i][j] = dp[i-1][j];
            } else {
                dp[i][j] = max(dp[i-1][j], val[i-1]+dp[i-1][j-wt[i-1]]);
            }
        }
    }

    cout << dp[n][w];
}

/*4 7
1 1
3 4
4 5
5 7*/