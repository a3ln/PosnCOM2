#include<bits/stdc++.h>
using namespace std;

int main(){
    int n, x;
    cin >> x >> n;
    vector<int> subset(n);
    for (int i = 0 ; i < n ; i++){
        cin >> subset[i];
    }

    bool t = false;
    for (int i = 0 ; i < (1<<n) ; i++){
        int sum = 0;
        for (int j = 0 ; j < n ; j++){
            if (i & (1<<j)) sum+=subset[j];
            if (sum == x) {
                t = true;
                break;
            }
        }
    }

    if (t) cout << "yes";
    else cout << "no";
}