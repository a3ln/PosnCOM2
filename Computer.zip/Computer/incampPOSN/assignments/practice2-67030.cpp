#include<bits/stdc++.h>
using namespace std;

// O(n log n)
int bsearch(vector<int> &v, int start, int end){
    if (start>end) return -1;
    int mid = (start+end)/2;
    if (v[mid+1]==mid && v[mid]==mid) return v[mid];
    if (v[mid]==mid) return bsearch(v, mid+1, end);
    return bsearch(v, start, mid-1);
}

int main(){
    vector<int> v = {0, 1, 10, 19, 15, 14, 9, 13, 12, 11, 8, 7, 3, 4, 6, 16, 17, 20, 2, 5, 18, 16};

    sort(v.begin(), v.end());
    cout << bsearch(v, 0, v.size()-1) << endl;
}