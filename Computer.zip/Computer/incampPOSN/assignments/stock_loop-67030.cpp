#include<bits/stdc++.h>
using namespace std;

#define tup tuple<int, int, int>

tup kadane(vector<int> &sub) {
    int maxx = sub[0];
    int minn = sub[0];
    int sum = 0;
    int currmax = 0;
    int currmin = 0;
    int n = sub.size();
    int start = 0, end = 0, temp_start = 0;
    for (int i = 0; i < n; i++) {
        currmax += sub[i];
        if (currmax < sub[i]) {
            currmax = sub[i];
            temp_start = i; 
        }
        if (currmax > maxx) {
            maxx = currmax;
            start = temp_start;
            end = i;
        }
        currmin += sub[i];
        if (currmin > sub[i]) {
            currmin = sub[i];
        }
        if (currmin < minn) {
            minn = currmin;
        }
        sum += sub[i];
    }

    int normal = maxx;
    int circular = sum - minn;
    if (minn == sum) {
        return {start, end, normal};
    }
    int ans = max(normal, circular);
    if (ans == normal) {
        return {start, end, ans};
    } else {
        return {end + 1, start - 1, ans};
    }
}

int main() {
    int n;
    cin >> n;
    vector<int> price(n);
    for (int i = 0; i < n; i++) {
        cin >> price[i];
    }

    tup ans = kadane(price);
    int maxx = get<2>(ans);
    int x = get<0>(ans);
    int y = get<1>(ans);

    cout << x << " -> " << y << " : " << maxx << endl;
}