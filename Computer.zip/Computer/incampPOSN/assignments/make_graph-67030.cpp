#include<bits/stdc++.h>
using namespace std;

void adj_matrix(){
    int n, m; //number of node and number of edges
    cin >> n >> m;
    vector<vector<int>> adjm(n, vector<int>(n, 0));
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adjm[u-1][v-1] = w;
    }
    for (auto i : adjm){
        for (auto j : i){
            cout << j << " ";
        }
        cout << endl;
    }
}

void adj_list(){
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> adjl(n+1);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        adjl[u].push_back({v, w});
    }

    for (int i = 0 ; i < n ; i++){
        int u = i+1;
        for (auto j : adjl[i]){
            int v = j.first+1;
            int w = j.second;

            printf("%d -> %d : %d\n", u, v, w);
        }
    }
}

void edge_list(){
    int n, m;
    cin >> n >> m;
    vector<pair<int, pair<int, int>>> el;
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        el.push_back({w, {u, v}});
    }

    for (int i = 0 ; i < m ; i++){
        int w = el[i].first;
        int u = ++el[i].second.first;
        int v = ++el[i].second.second;

        printf("%d -> %d : %d\n", u, v, w);
    }
}

int main(){
    // adj_matrix();
    // adj_list();
    edge_list();
}

/*7 10
1 2 6
1 3 5
1 4 5
3 2 -2 
4 3 -2
2 5 -1
3 5 1
4 6 -1
6 7 3
5 7 3*/