#include<bits/stdc++.h>
using namespace std;

int calculate(vector<int> &route, vector<vector<int>> &mat){
    int total = 0;
    for (int i = 0 ; i < route.size()-1 ; i++){
        total+=mat[route[i]][route[i+1]];
    }
    total+=mat[route[route.size()-1]][route[0]];
    return total;
}

// 0 1 3 2 : 80
void permutation(vector<int> &cit, vector<vector<int>> &ans, int n){
    if (n == cit.size()) {
        ans.push_back(cit);
        return;
    }
    for (int i = n ; i < cit.size() ; i++){
        swap(cit[n], cit[i]);
        permutation(cit, ans, n+1);
        swap(cit[n], cit[i]);
    }
}

int main(){
    vector<int> cit = {0, 1, 2, 3};
    vector<vector<int>> mat = {{0, 10, 15, 20}, {10, 0, 35, 25}, {15, 35, 0, 30}, {20, 25, 30, 0}};

    vector<int> best;
    int min_dis = INT_MAX;
    vector<vector<int>> ans;
    permutation(cit, ans, 0);
    for (auto i : ans){
        int curr = calculate(i, mat);
        if (curr < min_dis){
            min_dis = curr;
            best = i;
        }
    }

    for (auto i : best) cout << i << " ";
    cout << ": " << min_dis;
}