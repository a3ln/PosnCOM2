#include<bits/stdc++.h>
using namespace std;

int binary_search(vector<int> &num, int n, int first, int last){
    int mid = (first+last)/2;

    if (first>=last) return -1;
    else if (num[mid]==n) return mid+1;
    else if (num[mid]<n) return binary_search(num, n, mid+1, last);
    else return binary_search(num, n, first, mid-1);
}

int main(){
    int n;
    cout << "Input number of the data : ";
    cin >> n;
    vector<int> num;
    cout << "Input the data(s) : " << endl;
    for (int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        num.push_back(a);
    }
    int s;
    cout << "Enter the number you want to search : ";
    cin >> s;

    cout << "Index of that number is " << binary_search(num, s, 0, num.size()-1) << endl;
}