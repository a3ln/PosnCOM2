#include<bits/stdc++.h>
using namespace std;

int binary(vector<int> &num, int n, int first, int last){
    int mid = (first+last)/2;

    if (first>=last) return -1;
    else if (num[mid]==n) return mid+1;
    else if (num[mid]<n) return binary(num, n, mid+1, last);
    else return binary(num, n, first, mid-1);
}

int main(){
    vector<int> a1 =  {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};

    vector<int> s = {16, 88};
    for (auto n : s){
        cout << "(Implement) " << "Where's " << n << " exist : " << binary(a1, n, 0, a1.size()-1) << endl;
        cout << "Is " << n << " exist : " << binary_search(a1.begin(), a1.end(), n) << endl;
        cout << "The position of " << n << " is " << lower_bound(a1.begin(), a1.end(), n)-a1.begin() << endl;
        cout << "The position of " << n << " is " << upper_bound(a1.begin(), a1.end(), n)-a1.begin() << endl;
        cout << endl;
    }
}