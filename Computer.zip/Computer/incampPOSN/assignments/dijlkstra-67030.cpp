#include<bits/stdc++.h>
using namespace std;

int n;
vector<int> dis;
void add_edge(int u, int v, int w, vector<vector<pair<int, int>>> &path){
    path[u].push_back({v, w});
}

void dijkstra(vector<vector<pair<int, int>>> &path, int s){
    dis.resize(n, INT_MAX);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    dis[s] = 0;
    pq.push({dis[s], s});
    while(!pq.empty()){
        int u = pq.top().second;
        pq.pop();

        for (auto i : path[u]){
            int v = i.first;
            int w = i.second;
            if (dis[v]>dis[u]+w){
                dis[v] = dis[u]+w;
                pq.push({dis[v], v});
            }
        }
    }
}

int main(){
    int m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        add_edge(u, v, w, path);
    }

    dijkstra(path, 2);

    for (int i = 0 ; i < n ; i++){
        cout << 2 << " -> " << i << " : " << dis[i] << "\n";
    }
}

/*5 7
2 3 7
2 1 2
2 0 6
1 3 3
1 4 6
3 4 5
0 4 1*/