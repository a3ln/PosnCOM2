#include<bits/stdc++.h>
using namespace std;

int main(){
    int n, target;
    cin >> n >> target;
    vector<int> info(n);
    for (int i = 0 ; i < n ; i++){
        cin >> info[i];
    }
    sort(info.begin(), info.end());

    int l = 0, r = n-1;
    while (l<r){
        int sum = info[l]+info[r];
        if (sum  == target) {
            cout << "Yes";
            return 0;
        } else if (sum<target){
            l++;
        } else if (sum>target){
            r--;
        }
    }
    cout << "No";
}