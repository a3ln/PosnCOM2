#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    for (int b = 1234 ; b <= 98765/n ; b++){
        int a = b*n;
        int temp, used = (b < 10000/*10k*/);
        temp = a;
        while (temp){
            used |= 1<<(temp%10);
            temp /= 10;
        }
        temp = b;
        while(temp){
            used |= 1<<(temp%10);
            temp /= 10;
        }
        if (used == (1<<10)-1){
            printf("%05d / %05d = %d\n", a, b, n);
        }
    }
}