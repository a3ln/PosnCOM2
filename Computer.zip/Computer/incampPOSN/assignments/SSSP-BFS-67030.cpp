#include<bits/stdc++.h>
using namespace std;

int n;
vector<int> dis;
vector<int> parent;
void add_edge(int u, int v, vector<vector<int>> &path){
    path[u].push_back(v);
    path[v].push_back(u);
}

void print_path(int u, int s){
    if (u == s) {
        cout << s;
        return;
    }
    // if (parent[u] == -1) return;
    print_path(parent[u], s);
    cout << " " << u;
}

void bfs(vector<vector<int>> &path, int s){
    dis.resize(n, INT_MAX);
    parent.resize(n, -1);
    queue<int> q;

    dis[s] = 0;
    q.push(s);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for (auto v : path[u]){
            if (dis[v]==INT_MAX){
                dis[v] = dis[u]+1;
                parent[v] = u;
                q.push(v);
            }
        }
    }
}

int main(){
    int m;
    cin >> n >> m;
    vector<vector<int>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v;
        cin >> u >> v;
        add_edge(u, v, path);
    }

    bfs(path, 5);

    for (int i = 0 ; i < n ; i++){
        cout << i << " : ";
        print_path(i, 5);
        cout << " (" << dis[i] << ")\n";
    }
}

/*13 16
0 1
1 2
2 3
0 4
1 5
2 6
3 7
5 6
4 8
8 9
9 10
10 11
5 10
11 12
6 11
7 12*/