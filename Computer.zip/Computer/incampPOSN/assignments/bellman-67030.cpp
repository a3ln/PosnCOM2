#include<bits/stdc++.h>
using namespace std;

int n;
vector<int> dis;
void add_edge(int u, int v, int w, vector<vector<pair<int, int>>> &path){
    path[u].push_back({v, w});
}

void bellman(vector<vector<pair<int, int>>> &path, int s){
    dis.resize(n, INT_MAX);
    dis[s] = 0;
    
    for (int i = 0 ; i < n-1 ; i++){
        for (int u = 0 ; u < n ; u++){
            for (auto j : path[u]){
                int v = j.first;
                int w = j.second;
                dis[v] = min(dis[v], dis[u]+w);
            }
        }
    }

    bool neg = false;
    for (int u = 0 ; u < n ; u++){
        for (auto j : path[u]){
            int v = j.first;
            int w = j.second;
            if (dis[v]>dis[u]+w){
                neg = true;
            }
        }
    }

    if (neg) cout << "This graph has negative cycle.";
    else cout << "This graph doesn't have negative cycle.";
}

int main(){
    int m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        add_edge(u, v, w, path);
    }

    bellman(path, 0);
}

/*5 5
0 1 1
1 2 1
2 3 3
3 4 -3
4 0 -3*/