#include<bits/stdc++.h>
using namespace std;

int multi(vector<int> &p, int i, int j, vector<vector<int>> &dp){
    if (i+1==j) return 0;

    if (dp[i][j]!=-1) return dp[i][j];

    int res = INT_MAX;

    for (int k = i+1 ; k < j ; k++){
        int curr = multi(p, i, k, dp) + multi(p, k, j, dp) + p[i]*p[k]*p[j];
        res = min(curr, res);
    }

    dp[i][j] = res;

    return res;
}

int main(){
    int n;
    cin >> n;
    vector<int> p(n+1);
    for (int i = 0 ; i <= n ; i++){
        cin >> p[i];
    }

    vector<vector<int>> dp(n+1, vector<int>(n+1, -1));
    cout << multi(p, 0, p.size()-1, dp);
}