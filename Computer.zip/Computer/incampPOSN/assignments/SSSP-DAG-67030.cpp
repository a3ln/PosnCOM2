#include<bits/stdc++.h>
using namespace std;

int n;
vector<bool> visited;
vector<vector<pair<int, int>>> path;
stack<int> ans;
vector<int> dis;
void add_edge(int u, int v, int w, vector<vector<pair<int, int>>> &path){
    path[u].push_back({v, w});
}

void topo_sort(int u){
    visited[u] = true;
    for (auto i : path[u]){
        int v = i.first;
        if (!visited[v]){
            topo_sort(v);
        }
    }
    //until reach the end then add (backtracking)
    ans.push(u);
}

void shortest_path(int s){
    for (int i = 0 ; i < n ; i++){
        if (!visited[i]){
            topo_sort(i);
        }
    }
    dis[s] = 0;

    while (!ans.empty()){
        int u = ans.top();
        ans.pop();

        if (dis[u] != INT_MAX){
            for (auto i : path[u]){
                int v = i.first;
                int w = i.second;
                if (dis[v]>dis[u]+w){
                    dis[v] = dis[u]+w;
                }
            }
        }
    }

    for (int i = 0 ; i < n ; i++){
        if (dis[i] == INT_MAX) cout << "INFINITY ";
        else cout << dis[i] << " ";
    }
}

int main(){
    int m;
    cin >> n >> m;
    path.resize(n);
    dis.resize(n, INT_MAX);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        add_edge(u, v, w, path);
    }
    visited.resize(n, false);

    shortest_path(1);
}

/*6 9
0 1 5
0 2 3
1 3 6
1 2 2
2 4 4
2 5 2
2 3 7
3 4 -1
4 5 -2*/