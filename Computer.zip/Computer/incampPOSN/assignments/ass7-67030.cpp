#include<bits/stdc++.h>
using namespace std;

void add_edge(vector<vector<int>> &adj, int u, int v){
    adj[u].push_back(v);
    adj[v].push_back(u);
}

void add_edge2(vector<vector<pair<int, int>>> &adj, int u, int v, int w){
    adj[u].push_back({v, w});
    adj[v].push_back({u, w});
}

void dfs(int u, vector<vector<int>> &adj, vector<bool> &visited){
    visited[u] = true;
    cout << u << " ";

    for (auto i : adj[u]){
        if (!visited[i]){
            dfs(i, adj, visited);
        }
    }
}

int main(){
    int n = 5;
    vector<vector<int>> adj(n);

    add_edge(adj, 0, 1);
    add_edge(adj, 0, 4);
    add_edge(adj, 1, 4);
    add_edge(adj, 1, 2);
    add_edge(adj, 1, 3);
    add_edge(adj, 2, 3);
    add_edge(adj, 3, 4);

    vector<bool> visited(n, false);
    dfs(0, adj, visited);

    vector<vector<pair<int, int>>> adj2(n);
    add_edge2(adj2, 0, 1, 10);
    add_edge2(adj2, 0, 4, 12);
    add_edge2(adj2, 1, 2, 15);
    add_edge2(adj2, 1, 3, 25);
    add_edge2(adj2, 1, 4, 7);
    add_edge2(adj2, 2, 3, 20);
    add_edge2(adj2, 3, 4, 8);

    cout << endl << "-----------------------" << endl;
    for (int i = 0 ; i < n ; i++){
        cout << i << " | ";
        for (auto j : adj2[i]){
            cout << "(" << j.first << "," << j.second << ")" << " ";
        }
        cout << endl;
    }
}