#include<bits/stdc++.h>
using namespace std;

void bubble_sort(vector<int> &num, int n){
    cout << "Bubble sort" << endl;
    for (int i = 0 ; i < n ; i++){
        bool swapp = false;
        for (int j = 0 ; j < n-i-1 ; j++){
            if (num[j] > num[j+1]) {
                int temp = num[j];
                num[j] = num[j+1];
                num[j+1] = temp;
                swapp = true;
            }
        }
        if (!swapp) break;
    }
}

void insertion_sort(vector<int> &num){
    cout << "Insertion sort" << endl;
    int n = num.size();
    for (int i = 1 ; i < n ; i++){
        int key = num[i];
        int j = i-1;
        while (j >= 0 && num[j] > key){
            num[j+1] = num[j]; // num[j+1] = key
            j--;
        }
        num[j+1] = key;
    }
}

void selection_sort(vector<int> &num){
    cout << "Selection sort" << endl;
    int n = num.size();

    for (int i = 0 ; i < n-1 ; i++){
        for (int j = i+1 ; j < n ; j++){
            if (num[i]>num[j]) {
                swap(num[i], num[j]);
            }
        }
    }
}

void merge(vector<int> &num, int first, int last, int mid){
    int n1 = mid-first+1;
    int n2 = last-mid;

    vector<int> left(n1), right(n2);

    // new copy so that the index is equal
    for (int i = 0 ; i < n1 ; i++){
        left[i] = num[first+i];
    }
    for (int i = 0 ; i < n2 ; i++){
        right[i] = num[mid+1+i];
    }

    int i = 0, j = 0;
    int k = first;

    while(i < n1 && j < n2){
        if (left[i] <= right[j]){
            num[k] = left[i];
            i++;
        } else {
            num[k] = right[j];
            j++;
        }
        k++;
    }

    while(i < n1){
        num[k] = left[i];
        i++;
        k++;
    }
    while (j < n2){
        num[k] = right[j];
        j++;
        k++;
    }
}

void merge_sort(vector<int> &num, int first, int last){
    if (last<=first) return;
    int mid = first + (last-first)/2;

    merge_sort(num, first, mid);
    merge_sort(num, mid+1, last);
    merge(num, first, last, mid);
}

int partition(vector<int> &num, int low, int high){
    int pivot = num[high];
    int i = low-1;
    
    for (int j = low ; j<=high ; j++){
        if (num[j]<pivot){
            i++;
            swap(num[i], num[j]);
        }
    }
    swap(num[i+1], num[high]);
    return i+1;
}

void quick_sort(vector<int> &num, int low, int high){
    if (low < high){
        int pivot = partition(num, low, high);

        quick_sort(num, low, pivot-1);
        quick_sort(num, pivot, high);
    }
}

int main(){
    int n;
    cout << "Input number of the data : ";
    cin >> n;
    vector<int> num;
    cout << "Input the data(s) : " << endl;
    for (int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        num.push_back(a);
    }

    // bubble_sort(num, n);
    // insertion_sort(num);
    // selection_sort(num);
    // merge_sort(num, 0, num.size()-1);
    quick_sort(num, 0, num.size()-1);

    for (auto i : num){
        cout << i << " ";
    }
}