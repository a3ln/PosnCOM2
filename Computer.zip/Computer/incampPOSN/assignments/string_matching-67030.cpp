#include<bits/stdc++.h>
using namespace std;

int brute_force(string &s, string &p){
    int n = s.size(), m = p.size();
    for (int i = 0 ; i <= n-m ; i++){
        int j = 0;
        while (j<m && s[i+j] == p[j]){
            j++;
        }
        if (j == m) {
            return i;
        }
    }
    return -1;
}

int searching_mono(string &s, string &p){
    int n = s.size(), m = p.size();
    auto index = search(s.begin(), s.end(), p.begin(), p.end());
    if (index == s.end()) return -1;
    else return index-s.begin();
}

void searching(vector<int> &res, string &s, string &p){
    int n = s.size(), m = p.size();
    for (int i = 0 ; i < n-m ; i++){
        auto index = search(s.begin(), s.end(), p.begin(), p.end());
        if (index == s.end()) res.push_back(-1);
        else res.push_back(index-s.begin());
        *index = '0';
    }
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    string s, p;
    cin >> s >> p;

    int ans;
    // ans = brute_force(s, p);

    ans = searching_mono(s, p);
    cout << ans;

    // vector<int> res;
    // searching(res, s, p);
    // for (auto i : res){
    //     if (i!=-1) cout << i << " ";
    // }
}

/*ababcabcabababd
ababd*/