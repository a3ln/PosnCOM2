#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<int> num;
    for (int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        num.push_back(a);
    }

    int maxx = num[0];
    for (auto i : num){
        if (i > maxx) maxx = i;
    }
    cout << maxx << endl;
}