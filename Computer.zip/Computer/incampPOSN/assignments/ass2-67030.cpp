#include<bits/stdc++.h>
using namespace std;

int main(){
    int **x = new int*[5];
    int n = 10;
    
    for (int i=0 ; i<5 ; i++){
        *x = new int[3];
        for (int j = 0 ; j < 3 ; j++){
            n+=10;
            (*x)[j] = n;
        }
    }

    for (int i = 0 ; i < 5 ; i++){
        for (int j = 0 ; j<3 ;j++){
            cout << (*x)[j] << " ";
        }
        cout << endl;
    }
}