#include<bits/stdc++.h>
using namespace std;

struct node{
    int info;
    struct node *left;
    struct node *right;
};
typedef struct node *NODEPTR;

NODEPTR makeTree(int x){
    NODEPTR p;
    p = new node;
    p->info = x;
    p->left = NULL;
    p->right = NULL;
    return p;
}

void setleft(NODEPTR p, int x){
    p->left = makeTree(x);
}

void setright(NODEPTR p, int x){
    p->right = makeTree(x);
}

void add(NODEPTR q, int x){
    if (q->info > x) {
        if (q->left != NULL) return add(q->left, x);
        else {
            setleft(q, x);
        }
    }
    // right
    else {
        if (q->right != NULL) return add(q->right, x);
        else setright(q, x);
    }
}

void insertBST(NODEPTR &p, int x) {
    if (p == NULL) {
        p = new node;
        p->info = x;
        p->left = NULL;
        p->right = NULL;
    } else {
        if (x < p->info) {
            insertBST(p->left, x);
        } else {
            insertBST(p->right, x);
        }
    }
}

void inorder(NODEPTR p) {
    if (p != NULL) {
        inorder(p->left);
        cout << p->info << " ";
        inorder(p->right);
    }
}

int main(){
    // NODEPTR p = makeTree(7);
    // add(p, 6);
    // add(p, 3);
    // add(p, 8);
    // add(p, 4);
    // add(p, 10);
    // add(p, 16);

    NODEPTR p = NULL;
    insertBST(p, 7);
    insertBST(p, 1);
    insertBST(p, 6);
    insertBST(p, 10);
    insertBST(p, 8);
    insertBST(p, 2);
    insertBST(p, 19);

    inorder(p);
}