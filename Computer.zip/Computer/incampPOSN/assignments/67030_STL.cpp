#include<bits/stdc++.h>
using namespace std;

void one_stack(){
    string s;
    cout << "Enter math expression: ";
    cin >> s;

    stack<char> res;
    bool t = true;
    for (auto i : s){
        if (i=='(' || i == '[' || i=='{'){
            res.push(i);
        } else if (i == ')' || i == ']' || i == '}'){
            if (res.empty()) {
                cout << "Right is more than left" << endl;
                t = false;
                break;
            }
            else if (i == ')' && res.top() == '(') res.pop();
            else if (i == ']' && res.top() == '[') res.pop();
            else if (i == '}' && res.top() == '{') res.pop();
            else {
                cout << "Left and right are not the same type" << endl;
                t = false;
                break;
            }
        }
    }
    if (!res.empty() && t) {
        cout << "Left is more than right" << endl;
    } else if (res.empty() && t) cout << "Correct" << endl;
}

void two_queue(){
    // number of data to input
    int n;
    cout << "Enter number of data : ";
    cin >> n;
    cout << "Enter tha data(s) : " << endl;
    vector<queue<int>> ans1(1000);
    vector<queue<int>> ans2(1000);
    for (int i = 0 ; i < n ;i++){
        int a;
        cin >> a;
        //1
        int b = a%10;
        ans1[b].push(a);
        //2
        int c = floor(a/10);
        ans2[c].push(a);
    }

    cout << "Round 1 : ";
    for (int i = 0 ; i < 10;i++){
        if (!ans1[i].empty()){
            while (!ans1[i].empty()){
                cout << ans1[i].front() << " ";
                ans1[i].pop();
            }
        }
    }
    cout << endl << "Round 2 : ";
    for (int i = 0 ; i < 10 ;i++){
        if (!ans2[i].empty()){
            while (!ans2[i].empty()){
                cout << ans2[i].front() << " ";
                ans2[i].pop();
            }
        }
    }
    cout << endl;
}

// each problem for each void functon
int main(){
    one_stack();
    two_queue();
}