#include<bits/stdc++.h>
using namespace std;

struct node{
    int info;
    struct node *next;
};
typedef struct node *NODEPTR;
NODEPTR head = NULL;

void createList(int n){
    NODEPTR q, p;
    q = new node;
    q->info = n;
    q->next = NULL;

    if (head == NULL) head = q;
    else {
        p = head;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = q;
    }
}

void insertFront(int n){
    NODEPTR q;
    q = new node;
    q->info = n;
    if (head == NULL){
        head = q;
    } else {
        q->next = head;
        head = q;
    }
}

void insertLast(int n){
    NODEPTR q, p;
    q = new node;
    q->info = n;
    q->next = NULL;
    if (head == NULL){
        head = q;
    } else{
        p = head;
        while (p->next!=NULL){
            p = p->next;
        }
        p->next = q;
    }
}

void insertMiddle(int n){
    cout << "Input the position to insert new node : ";
    int v;
    cin >> v;

    NODEPTR q, p;
    q = new node;
    q->info = n;
    p = head;
    int c=1;
    while (c<v-1){
        c++;
        p = p->next;
    }
    q->next = p->next;
    p->next = q;

    cout << endl << "Insertion completed successfully." << endl;
}

void deleteFront(){
    cout << endl << "Data, after deletion of first node : " << endl;
    head = head->next;
}

void deleteLast(){
    cout << endl << "The new list after deletion the last node are : " << endl;
    NODEPTR q, p;
    
    p = head;
    while (p->next->next!=NULL && p->next!=NULL){
        p = p-> next;
    }
    
    q = p->next;
    p->next = NULL;
    delete q;
}

void deleteMiddle(){
    cout << endl << "Input the position of node to delete : ";
    int v;
    cin >> v;

    NODEPTR p, q;
    p = head;
    q = NULL;
    int c= 1;
    if (v == 1) {
        head = head->next;
        delete p;
        cout << endl << "Deletion completed successfully." << endl;
        return;
    }
    while (p!=NULL && c<v){
        c++;
        q = p;
        p=p->next;
    }

    q->next = p->next;
    delete p;

    cout << endl << "Deletion completed successfully." << endl;
}

void searchList(int n){
    NODEPTR q;
    q = head;
    int c = 1;
    while (q->next!=NULL && q->info!=n){
        q = q->next;
        c++;
    }
    cout << "Data found at node " << c << endl;
}

void displayList(){
    NODEPTR p;
    for (p = head ; p!=NULL;p=p->next){
        cout << "Data = " << p->info << endl;
    }
}

int main(){
    int n;
    cout << "Input the number of nodes : ";
    cin >> n;
    for (int i = 0 ; i < n ; i++){
        cout << "Input data for number " << i+1 << " : ";
        int a;
        cin >> a;
        createList(a);
    }

    cout << endl << "Data entered in the list :" << endl;
    displayList();

    int a;
    cout << endl << "Input data to insert at the beginning of the list : ";
    cin >> a;
    insertFront(a);
    cout << endl << "Data after inserted in the list are :" << endl;
    displayList();

    cout << endl << "Input data to insert at the end of the list : ";
    cin >> a;
    insertLast(a);
    cout << endl << "Data, after inserted in the list are :" << endl;
    displayList();

    cout << endl << "Input data to insert in the middle of the list : ";
    cin >> a;
    insertMiddle(a);
    cout << endl << "The new list are :" << endl;
    displayList();

    cout << "Data of node 1 which is being delete is : " << head->info << endl;
    deleteFront();
    displayList();

    deleteLast();
    displayList();

    deleteMiddle();
    cout << endl << "The new list are : " << endl;
    displayList();

    cout << "Input the element to be searched : ";
    int l;
    cin >> l;
    searchList(l);
}