#include<bits/stdc++.h>
using namespace std;

int binary_tree(int d, int n){
    if (d == 1) return 1+binary_tree(d*2, n-1);
    else if (n==0) return d;
    else return d+binary_tree(d*2, n-1);
}

int main(){
    int d;
    cin >> d;
    int ans = binary_tree(1, d);
    cout << ans << endl;
}