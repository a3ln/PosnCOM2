#include<bits/stdc++.h>
using namespace std;

int brute_force(int &a, int n, int &res){
    int c = 0;
    for (int i = 0 ; i < n ; i++){
        res*=a;
        c++;
    }
    return c;
}

int decrease(int a, int n, int &c){
    if (n == 0) return 1;
    else if (n == 1) return a;
    else if (n%2==0) {
        int half = decrease(a, n/2, c);
        c++;
        return half*half;
    }
    else {
        int half = decrease(a, (n-1)/2, c);
        c++;
        return half*half*a;
    }
}

int main(){
    int a, n;
    cin >> a >> n;
    int c = 1;
    int ans = decrease(a, n, c);
    cout << c << " " << ans << endl;
    int res = 1;
    cout << brute_force(a, n, res) << " " << res << endl;
}