#include<bits/stdc++.h>
using namespace std;

struct node{
    int info;
    struct node *next;
};
typedef struct node *NODEPTR;
NODEPTR head = NULL;

void Push(int x){
    NODEPTR p;
    p = new node;
    p->info = x;
    p->next = head;
    head = p;
}

int Pop(){
    NODEPTR p;
    int x;

    p = head;
    head = head->next;
    x = p->info;
    delete p;
    return x;
}

int Size(){
    NODEPTR p;
    int c = 0;
    p = head;
    while (p->next!=NULL){
        p=p->next;
        c++;
    }
    return c;
}

int main(){
    int n;
    cin >> n;

    while (n>0){
        Push(n%2);
        n/=2;
    }

    int num = Size()+1;
    for (int i = 0 ; i < num ; i++){
        cout << Pop();
    }
}