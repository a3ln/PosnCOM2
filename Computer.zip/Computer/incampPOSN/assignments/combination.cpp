#include<bits/stdc++.h>
using namespace std;

void combination(vector<int> &a, int target, vector<vector<int>> &res, vector<int> &curr, int i){
    if (i == a.size()){
        if (target == 0) {
            res.push_back(curr);
        }
        return;
    }

    if (a[i]<=target){
        curr.push_back(a[i]);
        target-=a[i];
        combination(a, target, res, curr, i);
        target+=a[i];
        curr.pop_back();
    }
    combination(a, target, res, curr, i+1);
}

int main(){
    vector<int> a = {10,20,40,30};
    int k = 60;

    sort(a.begin(), a.end());
    vector<vector<int>> res;
    vector<int> curr;
    combination(a, k, res, curr, a.size());
    for (auto i : res){
        for (auto j : i){
            cout << j << " ";
        }
        cout << endl;
    }
}