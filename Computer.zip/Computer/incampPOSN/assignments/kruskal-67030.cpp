#include<bits/stdc++.h>
using namespace std;

int n;
vector<vector<int>> path;
vector<int> parent;
vector<int> r;

void add_edge(int u, int v, int w){
    path.push_back({w, u, v});
    path.push_back({w, v, u});
}

int find_parent(int i){
    if (parent[i]==i) return i;
    return parent[i] = find_parent(parent[i]);
}

bool same(int i, int j){
    if (find_parent(i) == find_parent(j)) return true;
    return false;
}

void union_set(int i, int j){
    if (!same(i, j)){
        int x = find_parent(i);
        int y = find_parent(j);

        if (r[x] > r[y]){
            parent[y] = x;
        } else if (r[x] == r[y]) {
            parent[x] = y;
            r[y]++;
        } else {
            parent[x] = y;
        }
    }
}

void kruskal(){
    priority_queue<vector<int>, vector<vector<int>>, greater<vector<int>>> pq;
    for (auto i : path){
        pq.push(i);
        // cout << "*";
    }

    int sum = 0;
    int cunt = 0;
    while (!pq.empty()){
        vector<int> edge = pq.top();
        pq.pop();

        int w = edge[0];
        int u = edge[1];
        int v = edge[2];

        if (find_parent(u) != find_parent(v)){
            sum+=w;
            cunt++;
            union_set(u, v);
        }

        if (cunt == n-1) break; //negative weight cycle
    }
    cout << sum;
}

int main(){
    int m;
    cin >> n >> m;
    parent.resize(n);
    for (int i = 0 ; i < n ; i++){
        parent[i] = i;
    }
    r.resize(n, 0);
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        add_edge(u, v, w);
    }

    // cout << "*";
    kruskal();
}

/*7 9
6 1 10
6 5 25
1 2 28
2 3 16
5 7 24
5 4 22
7 4 18
7 2 14
4 3 12*/