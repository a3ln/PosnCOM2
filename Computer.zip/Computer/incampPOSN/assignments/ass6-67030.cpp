#include<bits/stdc++.h>
using namespace std;

void insertHeap(vector<int> &heap, int x){
    heap.push_back(x);

    int index = heap.size()-1;
    while (index != 0 && heap[(index-1)/2]>heap[index]){
        swap(heap[index], heap[(index-1)/2]);
        index = (index-1)/2;
    }
}

void deleteHeap(vector<int> &heap){
    int index = 0;
    heap[index] = heap[heap.size()-1];
    heap.pop_back();
    
    while(true){
        int left = index*2+1;
        int right = index*2+2;
        int smallest = index;

        if (left < heap.size() && heap[left] < heap[smallest]){
            smallest = left;
        } else if (right < heap.size() && heap[right] < heap[smallest]){
            smallest = right;
        }
        if (index != smallest){
            swap(heap[index], heap[smallest]);
            index = smallest;
        } else break;
    }
}

// min heap
// 23 15 17 13 31 10 2 4 29 14 5
int main(){
    vector<int> heap;
    vector<int> data = {23 ,15 ,17 ,13 ,31 ,10 ,2 ,4 ,29 ,14 ,5};
    for (auto i : data){
        insertHeap(heap, i);
    }
    for (auto i : heap){
        cout << i << " ";
    }
    deleteHeap(heap);
    cout << endl;
    for (auto i : heap){
        cout << i << " ";
    }
}