#include<bits/stdc++.h>
using namespace std;

int sum(vector<int> &a, int n){
    if (n == 0) return 0;
    return a[n-1]+sum(a, n-1);
}

int main(){
    int n;
    cin >> n;
    vector<int> a;
    for (int i = 0 ; i < n;i++){
        int z;
        cin >> z;
        a.push_back(z);
    }
    int ans = sum(a,n);
    cout << ans;
}