#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<int> people;
    for (int i = 0 ; i < n ; i++){
        people.push_back(i);
    }
    int s; // numbers of the limitation
    cin >> s;
    vector<tuple<int, int, int>> limit;
    for (int i = 0 ; i < s ; i++){
        int a, b, d;
        cin >> a >> b >> d;
        limit.push_back({a, b, d});
    }
    int ans = 0;
    do {
        bool t = true;
        for (auto i : limit){
            int a = get<0>(i);
            int b = get<1>(i);
            int d = get<2>(i);

            auto p = find(people.begin(), people.end(), a)-people.begin();
            auto q = find(people.begin(), people.end(), b)-people.begin();

            if (d > abs(p-q)) {
                t = false;
                break;
            }
        }
        if (t) ans++;
    } while(next_permutation(people.begin(), people.end()));

    cout << ans;
}