#include<bits/stdc++.h>
using namespace std;

void add_edge(int u, int v, vector<vector<int>> &path){
    path[u].push_back(v);
}

void topo_sort(vector<vector<int>> &path, int u, vector<bool> &visited, vector<int> &ans){
    visited[u] = true;
    for (auto v : path[u]){
        if (!visited[v]){
            topo_sort(path, v, visited, ans);
        }
    }
    //until reach the end then add (backtracking)
    ans.push_back(u);
}

int main(){
    int n, m;
    cin >> n >> m;
    vector<vector<int>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v;
        cin >> u >> v;
        add_edge(u, v, path);
    }

    vector<int> ans;
    vector<bool> visited(n, false);
    for (int u = 0 ; u < n ; u++){
        if (!visited[u]) topo_sort(path, u, visited, ans);
    }

    reverse(ans.begin(), ans.end());
    for (auto u : ans){
        cout << u << " -> ";
    }
}

/*8 8
0 1
0 2
1 2
1 3
2 3
3 4
2 5
7 6*/

/*8 8
7 6
0 1
0 2
1 3
1 2
2 5
2 3
3 4*/