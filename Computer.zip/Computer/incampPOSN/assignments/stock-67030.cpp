#include<bits/stdc++.h>
using namespace std;

#define tup tuple<int, int, int>
tup brute_force(vector<int> &price){
    int maxx = INT_MIN;
    int x, y;
    for (int i = 0 ; i < price.size() ; i++){
        for (int j = i+1 ; j < price.size() ; j++){
            if (maxx < price[j]-price[i]){
                maxx = price[j]-price[i];
                x = i;
                y = j;
            }
        }
    }
    return {x, y , maxx};
}

tup found(vector<int> &sub, int first, int mid, int end){
    int leftsum = INT_MIN;
    int sum = 0;
    int maxleft;
    for (int i = mid ; i > first ; i--){
        sum+=sub[i];
        if (sum>leftsum){
            leftsum = sum;
            maxleft = i;
        }
    }
    int maxright;
    int rightsum = INT_MIN;
    sum = 0;
    for (int i = mid+1 ; i < end ; i++){
        sum+=sub[i];
        if (sum>rightsum){
            rightsum = sum;
            maxright = i;
        }
    }
    return {maxleft, maxright, leftsum+rightsum};
}

tup divide(vector<int> &sub, int first, int end){
    if (first==end) return {first, end, sub[first]};
    else {
        int mid = (first+end)/2;
        tup left = divide(sub, first, mid);
        tup right = divide(sub, mid+1, end);
        tup cross = found(sub, first, mid, end);

        int leftsum = get<2>(left);
        int rightsum = get<2>(right);
        int crosssum = get<2>(cross);
        if (leftsum >= rightsum && leftsum >= crosssum) return left;
        else if (rightsum >= leftsum && rightsum >= crosssum) return right;
        else return cross;
    }
}

tup kadane(vector<int> &sub){
    int maxx = sub[0];
    int res = sub[0];
    int x = 0, y = 0;
    for (int i = 1 ; i < sub.size() ; i++){
        if (res+sub[i]>sub[i]){
            res = sub[i]+res;
        } else{
            res = sub[i];
            x = i;
        }

        if (res>maxx){
            maxx = res;
            y = i;
        }
    }
    return {x, y, maxx};
}

int main(){
    vector<int> price = {100, 113, 110, 85, 105, 102, 86, 63, 81, 101, 94, 106, 101, 79, 94, 90};
    vector<int> sub;
    for (int i = 1 ; i < price.size() ; i++){
        sub.push_back(price[i]-price[i-1]);
    }

    tup ans;
    // ans = brute_force(price);
    // if (get<2>(ans) < 0) cout << "Profit is negative";
    // else cout << get<0>(ans) << " -> " << get<1>(ans) << " : " << get<2>(ans) << endl;

    // ans = divide(sub, 0, price.size()-1);
    // if (get<2>(ans) < 0) cout << "Profit is negative";
    // else cout << get<0>(ans) << " -> " << get<1>(ans)+1 << " : " << get<2>(ans) << endl;

    ans = kadane(sub);
    if (get<2>(ans) < 0) cout << "Profit is negative";
    else cout << get<0>(ans) << " -> " << get<1>(ans)+1 << " : " << get<2>(ans) << endl;
}