#include<bits/stdc++.h>
using namespace std;

vector<int> wt;
vector<int> val;
vector<vector<int>> dp;

int knapsack(int n, int w){
    if (w == 0 || n == 0) return 0;
    int pick = 0;

    if (dp[n][w] != -1) return dp[n][w];

    if (wt[n]<=w){
        pick = val[n] + knapsack(n-1, w-wt[n]);
    }

    int not_pick = knapsack(n-1, w);

    return dp[n][w] = max(pick, not_pick);
}

int main(){
    int n, w;
    cin >> n >> w;
    wt.resize(n);
    val.resize(n);
    dp.resize(n+1, vector<int>(w+1, -1));
    for (int i = 0 ; i < n ; i++){
        cin >> wt[i] >> val[i];
    }

    cout << knapsack(n, w);
}

/*4 7
1 1
3 4
4 5
5 7*/