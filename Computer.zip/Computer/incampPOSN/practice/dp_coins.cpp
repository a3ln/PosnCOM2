#include<bits/stdc++.h>
using namespace std;

#define d double

int main(){
    int n;
    cin >> n;
    vector<d> percent(n+1);
    for (int i = 1 ; i <= n ; i++){
        cin >> percent[i];
    }

    vector<vector<d>> dp(n+1, vector<d>(n+1, 0));
    dp[0][0] = 1.0;
    for (int i = 1 ; i <= n ; i++){
        for (int j = 0 ; j <= i ; j++){
            dp[i][j] += dp[i-1][j]*(1.0-percent[i]);
            if (j!=0) dp[i][j] += dp[i-1][j-1]*percent[i];
        }
    }

    d ans = 0.0;
    for (int i = n/2+1 ; i <= n ; i++){
        ans+=dp[n][i];
    }
    printf("%.10lf\n", ans);
}