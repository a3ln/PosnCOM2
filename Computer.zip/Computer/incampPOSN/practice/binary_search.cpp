#include<bits/stdc++.h>
using namespace std;

int search(vector<int> &data, int first, int last, int a){
    if (first>last) return -1;
    int mid = (first+last)/2;
    if (data[mid]<a) return search(data, mid+1, last, a);
    else if (data[mid]>a) return search(data, 0, mid-1, a);
    else return mid;
}

int main(){
    int n;
    cout << "Enter number of the data : ";
    cin >> n;
    vector<int> data;
    cout << "Please enter the data from decending to ascending :" << endl;
    for (int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        data.push_back(a);
    }
    int a;
    cout << "Enter tha data you want to search : ";
    cin >> a;

    int ans = search(data, 0, data.size()-1, a);
    if (ans == -1) cout << "This number doesn't exist in the data." << endl;
    else cout << "The place is : " << ans+1 << endl;
}