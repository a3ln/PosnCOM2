#include<bits/stdc++.h>
using namespace std;

int knapsack(int W, vector<int> &profit, vector<int> &weight, int n){
    if (n==0 || W == 0) return 0;
    int pick = 0;

    if (weight[n] <= W){
        pick = profit[n] + knapsack(W-weight[n], profit, weight, n-1);
    }

    int not_pick = knapsack(W, profit, weight, n-1);

    return max(pick, not_pick);
}

int main(){
    vector<int> profit = {1,2,3};
    vector<int> weight = {4,5,1};
    int W = 4;

    cout << knapsack(W, profit, weight, profit.size()-1) << "\n";
}