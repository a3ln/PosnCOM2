#include<bits/stdc++.h>
using namespace std;

#define int unsigned long long

int C(int n, int k){
    if (k == 0 || k == n) return 1;
    if (k < 0 || k > n) return 0;
    return C(n-1, k-1) + C(n-1, k);
}

int C_top(int n, int k, vector<vector<int>> &dp){
    if (k==0 || k==n) return 1;
    if (k<0 || k>n) return 0;

    if (dp[n][k] != -1) return dp[n][k];

    return dp[n][k] = C_top(n-1, k-1, dp) + C_top(n-1, k, dp);
}

int C_bottom(int n, int k){
    vector<vector<int>> dp(n+1, vector<int>(k+1, -1));
    for (int i = 0 ; i <= k ; i++){
        dp[0][i] = 0;
    }
    for (int i = 0 ; i <= n ; i++){
        for (int j = 0 ; j <= k ; j++){
            if (j==0 || j==n) {
                dp[i][j] = 1;
                continue;
            }
            if (j<0 || j>n) {
                dp[i][j] = 0;
                continue;
            }
            if (dp[i][j] != -1) continue;
            dp[i][j] = dp[i-1][j-1] + dp[i-1][j];
        }
    }
    return dp[n][k];
}

int32_t main(){
    int n, k;
    cin >> n >> k;
    cout << C(n, k) << "\n";
    vector<vector<int>> dp(n+1, vector<int>(k+1, -1));
    cout << C_top(n, k, dp) << "\n";
    cout << C_bottom(n, k) << "\n";
}