#include<bits/stdc++.h>
using namespace std;

struct nodetype{
    char info;
    struct nodetype *left;
    struct nodetype *right;
};
typedef struct nodetype *NODEPTR;

NODEPTR makeTree(int x){
    NODEPTR p;
    p = new node;
    p->info = x;
    p->left = NULL;
    p->right = NULL;
    return p;
}

int setleft(NODEPTR p, int x){
    p->left = makeTree(x);
}

int setright(NODEPTR p, int x){
    p->right = makeTree(x);
}

int count(NODEPTR q, int x){
    if (q->info == x) return 1;
    // left
    else if (q->info > x) {
        if (q->left != NULL) return count(q->left, x);
        else {
            setleft(q, x);
        }
    }
    // right
    else if (q->info < x) {
        if (q->right != NULL) return count(q->right, x);
        else setright(q, x);
    }
}

int main(){
    int n;
    cin >> n;
    vector<int> data;
    for (int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        data.push_back(a);
    }
    NODEPTR q = makeTree(data[0]);
    int sum = 0;
    for (int i = 1 ; i < n ; i++){
        sum+=count(q, data[i]);       
    }
    cout << ans;
}