#include<bits/stdc++.h>
using namespace std;

void s_num(int prev, int a, int n){
    // cout << "*";
    if (a == 1) {
        cout << 1 << endl;
        s_num(1, a+1, n);
    } else if (a == n+1) {
        return;
    }
    else {
        prev += 2*a-1;
        cout << prev << endl;
        s_num(prev, a+1, n);
    }
}

int main(){
    int n;
    cin >> n;

    s_num(1, 1, n);
}