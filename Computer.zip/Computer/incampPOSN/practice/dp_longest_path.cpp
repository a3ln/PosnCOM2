#include<bits/stdc++.h>
using namespace std;

void dfs(int u, vector<vector<int>> &path, vector<int> &dp, vector<bool> &visited){
    visited[u] = true;
    for (auto v : path[u]){
        if (!visited[v]){
            dfs(v, path, dp, visited);
        }
        dp[u] = max(dp[u], dp[v]+1);
    }
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> path(n);
    for (int i = 0 ; i < m ; i++){
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        path[u].push_back(v);
    }

    vector<int> dp(n+1, 0);
    vector<bool> visited(n+1, false);

    for (int i = 0 ; i < n ; i++){
        if (!visited[i]){
            dfs(i, path, dp, visited);
        }
    }

    int ans = 0;
    for (int i = 0 ; i < n ; i++){
        ans = max(ans, dp[i]);
    }
    cout << ans;
}