#include<bits/stdc++.h>
using namespace std;

#define int long long
const int MOD = 1e9+7;

int walk(int n, int m, vector<vector<int>> &dp, vector<string> &grid){
    if (n<0 || m<0 || grid[n][m] == '#') return 0;
    if (n==0 && m==0) return 1;
    if (dp[n][m]!=-1) return dp[n][m];

    dp[n][m] = walk(n-1, m, dp, grid) + walk(n, m-1, dp, grid);
    
    return dp[n][m]%MOD;
}

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<string> grid(n);
    for (int i = 0 ; i < n ; i++){
        cin >> grid[i];
    }

    vector<vector<int>> dp(n, vector<int>(m, -1));
    cout << walk(n-1, m-1, dp, grid);
}

/*3 4
...#
.#..
....
*/