#include<bits/stdc++.h>
using namespace std;

int main(){
    int n, m, f, s;
    cin >> n >> m >> f >> s;
    vector<vector<pair<int, int>>> path(1001);
    for (int i = 0 ; i < n+m ; i++){
        char u, v;
        cin >> u >> v;
        u -= '0';
        v -= '0';
        if (u == 'X'-'0'){
            u = 0;
        }
        if (v == 'Y'-'0'){
            v = -1;
        }

        if (i < n){
            path[u].push_back({v, 1});
        } else {
            path[u].push_back({v, -1});
        }
    }

    vector<bool> visited(1001, false);
    vector<int> dis(1001, INT_MIN);
    priority_queue<pair<int, int>> pq;

    dis[0] = 0;
    pq.push({0, 0});
    while (!pq.empty()){
        int u = pq.top().second;
        pq.pop();

        if (visited[u]) continue;
        if (u == -1) break;
        visited[u] = true;
        
        for (auto i : path[u]){

        }
    }
}