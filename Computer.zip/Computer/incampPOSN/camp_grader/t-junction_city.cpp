#include<bits/stdc++.h>
using namespace std;

#define p pair<int, int>

vector<vector<p>> path;
vector<bool> visited;
vector<int> dis;
void dfs(int u){
    if (visited[u]) return;
    visited[u] = true;

    for (auto i : path[u]){
        int v = i.first;
        int w = i.second;
        if (!visited[v]){
            dfs(v);
            dis.push_back(w);
        }
    }
}

bool check(int mid){
    int c = 0;
    int sum = 0;
    for (auto i : dis){
        sum+=i;
        if (sum>=mid){
            sum = 0;
            c++;
        }
    }
    if (c<3) return true;
    else return false;
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    int m = n;
    n++;
    path.resize(n);
    int minn = INT_MAX, maxx = INT_MIN;
    for (int i = 0 ; i < m ; i++){
        int u, v, w;
        cin >> u >> v >> w;
        path[u].push_back({v, w});
        path[v].push_back({u, w});
        minn = min(minn, w);
        maxx = max(maxx, w);
    }

    int s;
    visited.resize(n, false);
    for (int i = 0 ; i < n ; i++){
        if (path[i].size() == 1){
            s = i;
            break;
        }
    }
    dfs(s);

    int l = 0;
    int r = INT_MAX;
    int curr = r;
    while (l<r){
        int mid = (r+l)/2;
        if (check(mid)){
            curr = r;
            r = mid; //decrease
        } else {
            l = mid+1; //increase
        }
    }
    cout << l-1;
}

/*8
0 1 9
1 2 8
2 3 11
3 4 50
4 5 1
3 6 13
6 7 12
6 8 32*/