#include<bits/stdc++.h>
using namespace std;

#define int long long
bool comp(int a, int b){
    return a>b;
}

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    vector<int> p(n);
    vector<int> b(n);
    for (int i = 0 ; i < n ; i++){
        cin >> p[i];
    }
    for (int i = 0 ; i < n ; i++){
        cin >> b[i];
    }

    sort(p.begin(), p.end());
    sort(b.begin(), b.end(), comp);

    vector<int> ans(n);
    for (int i = 0 ; i < n ; i++){
        ans[i] = p[i]+b[i];
    }
    sort(ans.begin(), ans.end());

    int sum = 0;
    for (int i = 1 ; i < n ; i++){
        sum+=(ans[i]-ans[i-1]);
    }
    cout << sum;
}