#include<bits/stdc++.h>
using namespace std;

#define int long long
vector<int> cat;

bool check(int mid){
    stack<int> s;
    int c = cat.size();
    for (auto i : cat){
        if (i <= mid) {
            c--;
            continue; // 3 
        }
        if (s.empty() || s.top()!=i){
            s.push(i);
        } else if (s.top()==i){
            c-=2;
        }
    }

    if (c<=0) return true;
    return false;
}

int32_t main(){
    int n;
    cin >> n;
    cat.resize(n);
    int maxx = INT_MIN;
    for (int i = 0 ; i < n ; i++){
        cin >> cat[i];
        maxx = max(maxx, cat[i]);
    }

    int l = 0;
    int r = maxx;
    int curr = r;
    while (l<=r){
        int mid = l+(r-l)/2;
        if (check(mid)){
            curr = mid;
            r = mid-1; //decrease
        } else {
            l = mid+1; //increase
        }
    }

    cout << curr;
}