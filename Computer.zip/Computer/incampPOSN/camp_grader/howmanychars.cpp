#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    char a;
    int n;
    cin >> a >> n;
    vector<int> ans(n, 0);
    for (int i = 0 ; i < n ; i++){
        string s;
        cin >> s;

        for (auto j : s){
            if (j == a) ans[i]++;
        }
    }

    for (auto i : ans) cout << i << "\n";
}