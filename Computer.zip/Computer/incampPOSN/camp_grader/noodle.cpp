#include<bits/stdc++.h>
using namespace std;

int main()[
    int n, m, k;
    cin >> n >> m >> k;
    vector<int> store(n);
    for (int i = 0 ; i < n ; i++){
        cin >> store[i];
    }

    
]