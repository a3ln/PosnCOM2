#include<bits/stdc++.h>
using namespace std;

#define p pair<int, int>
#define pp pair<int, pair<int, int>>

int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<string> path(n);
    vector<vector<int>> dis(n, vector<int>(m, INT_MAX));
    // vector<vector<bool>> visited(n, vector<bool>(m, false));
    queue<p> pq;
    for (int i = 0 ; i < n ; i++) {
        cin >> path[i];
        for (int j = 0 ; j < m ; j++) {
            if (path[i][j] == 'X') {
                pq.push({i, j});
                dis[i][j] = 0;
                // visited[i][j] = true;
            }
        }
    }

    int c = 0;
    int sum = 0;
    vector<vector<int>> dir = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
    while (!pq.empty()) {
        // cout << "*";
        int i = pq.front().first;
        int j = pq.front().second;
        pq.pop();

        if (path[i][j]=='A') {
            c++;
            sum+=dis[i][j]*2;
        }

        for (auto d : dir) {
            int iN = i + d[0];
            int jN = j + d[1];

            if (iN>=0 && iN<n && jN>=0 && jN<m && path[iN][jN]!='X' && path[iN][jN]!='W' && dis[iN][jN] == INT_MAX) {
                dis[iN][jN] = dis[i][j]+1;
                pq.push({iN, jN});
            }
        }
    }

    cout << c << " " << sum;
}

/*5 5
EEEEE
AEAEW
WEEWW
WEEXE
WWEXA*/