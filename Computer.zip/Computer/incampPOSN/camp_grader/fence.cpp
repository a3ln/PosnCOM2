#include<bits/stdc++.h>
using namespace std;

int main(){
    vector<int> ans;
    for (int z = 0 ; z < 2 ; z++){
        int n, m;
        cin >> n >> m;
        int t;
        cin >> t;
        vector<vector<int>> tree(n, vector<int>(m, 0));
        for (int i = 0 ; i < t ; i++){
            int x, y;
            cin >> x >> y;
            tree[x][y] = 1;
        }

        
    }

    for (auto i : ans){
        cout << i << "\n";
    }
}