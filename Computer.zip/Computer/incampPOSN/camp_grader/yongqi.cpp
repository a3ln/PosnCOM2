#include<bits/stdc++.h>
using namespace std;

int walk(vector<vector<int>> &path, int x, int y, int desX, int desY, int n){
    vector<vector<int>> dis(n+1, vector<int>(n+1, INT_MAX));
    vector<vector<bool>> visited(n+1, vector<bool>(n+1, false));
    priority_queue<pair<int, pair<int, int>>, vector<pair<int, pair<int, int>>>, greater<pair<int, pair<int, int>>>> pq;

    dis[x][y] = 0;
    pq.push({0, {x, y}});

    while (!pq.empty()){
        int xu = pq.top().second.first;
        int yu = pq.top().second.second;
        // cout << xu << yu << "\n";
        pq.pop();

        if (xu == desX && yu == desY){
            return dis[xu][yu];
        }
        if (visited[xu][yu]) continue;
        visited[xu][yu] = true;

        int xv_N = xu-1;
        int yv_N = yu;
        if (xv_N > 0){
            if (!visited[xv_N][yv_N] && path[xv_N][yv_N] != -1 && dis[xv_N][yv_N] > dis[xu][yu]+abs(path[xu][yu]-path[xv_N][yv_N])+1){
                dis[xv_N][yv_N] = dis[xu][yu]+abs(path[xu][yu]-path[xv_N][yv_N])+1;
                pq.push({dis[xv_N][yv_N], {xv_N, yv_N}});
            }
        }

        int xv_E = xu;
        int yv_E = yu+1;
        if (yv_E <= n){
            if (!visited[xv_E][yv_E] && path[xv_E][yv_E] != -1 && dis[xv_E][yv_E] > dis[xu][yu]+abs(path[xu][yu]-path[xv_E][yv_E])+1){
                dis[xv_E][yv_E] = dis[xu][yu]+abs(path[xu][yu]-path[xv_E][yv_E])+1;
                pq.push({dis[xv_E][yv_E], {xv_E, yv_E}});
            }
        }

        int xv_S = xu+1;
        int yv_S = yu;
        if (xv_S <= n){
            if (!visited[xv_S][yv_S] && path[xv_S][yv_S] != -1 && dis[xv_S][yv_S] > dis[xu][yu]+abs(path[xu][yu]-path[xv_S][yv_S])+1){
                dis[xv_S][yv_S] = dis[xu][yu]+abs(path[xu][yu]-path[xv_S][yv_S])+1;
                pq.push({dis[xv_S][yv_S], {xv_S, yv_S}});
            }
        }

        int xv_W = xu;
        int yv_W = yu-1;
        if (yv_W > 0){
            if (!visited[xv_W][yv_W] && path[xv_W][yv_W] != -1 && dis[xv_W][yv_W] > dis[xu][yu]+abs(path[xu][yu]-path[xv_W][yv_W])+1){
                dis[xv_W][yv_W] = dis[xu][yu]+abs(path[xu][yu]-path[xv_W][yv_W])+1;
                pq.push({dis[xv_W][yv_E], {xv_W, yv_W}});
            }
        }
    }

    return -1;
}

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, k, p, X, Y, H;
    cin >> n >> k >> p >> X >> Y >> H;
    vector<vector<int>> path(n+1, vector<int>(n+1, -1));
    path[X][Y] = H;
    vector<pair<int, int>> des;
    for (int i = 0 ; i < k ; i++){
        int x, y, h;
        cin >> x >> y >> h;
        des.push_back({x, y});
        path[x][y] = h;
    }
    for (int i = 0 ; i < p ; i++){
        int x, y, h;
        cin >> x >> y >> h;
        path[x][y] = h;
    }

    vector<int> ans;
    int c = 0;
    for (auto i : des){
        int x = i.first;
        int y = i.second;

        int d = walk(path, X, Y, x, y, n);
        if (d != -1) ans.push_back(d);
    }

    if (ans.size()==k) {
        // // cout << "what";
        // for (auto i : ans){
        //     cout << i << "\n";
        // }
        cout << *max_element(ans.begin(), ans.end()) << "\n" << *min_element(ans.begin(), ans.end());
    } else {
        // cout << "hi";
        cout << k-ans.size();
    }
}

/*4 1 14 3 2 1
4 4 1
1 1 1
1 2 1
1 3 7
1 4 1
2 1 1
2 2 2
2 3 7
2 4 1
3 1 -1
3 3 7
3 4 1
4 1 1
4 2 1
4 3 1

4 2 13 3 2 1
1 4 1
4 4 1
1 1 1
1 2 1
1 3 7
2 1 1
2 2 2
2 3 7
2 4 1
3 1 -1
3 3 7
3 4 1
4 1 1
4 2 1
4 3 1

4 2 8 3 2 1
1 4 1
4 4 1
1 1 1
1 2 1
1 3 7
2 1 1
2 2 2
2 3 7
2 4 1
3 1 -1*/