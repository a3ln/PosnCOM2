#include<bits/stdc++.h>
using namespace std;

#define int long long
vector<int> worker;
bool check(int mid, int n){
    int sum = 0;
    for (auto i : worker){
        sum += mid/i;
    }
    if (sum>=n) return true;
    return false;
}

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int m, n;
    cin >> m >> n;
    worker.resize(m);
    for (int i = 0 ; i < m ; i++){
        cin >> worker[i];
    }

    int l = *min_element(worker.begin(), worker.end());
    int r = *max_element(worker.begin(), worker.end())*n;
    int curr = r;
    while (l<=r){
        int mid = l+(r-l)/2;
        if (check(mid, n)){
            curr = mid;
            r = mid-1; //decrease
        } else {
            l = mid+1; //increase
        }
    }
    cout << l;
}