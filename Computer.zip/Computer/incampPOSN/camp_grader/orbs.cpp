#include<bits/stdc++.h>
using namespace std;

#define int unsigned long long

int32_t main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, l;
    cin >> n >> l;
    int a, b;
    cin >> a >> b;
    vector<int> info;
    multiset<int> ma, mab, mb;
    for (int i = 0 ; i < n ; i++){
        int z;
        cin >> z;
        info.push_back(z);
    }

    sort(info.begin(), info.end());
    for (int i = 0 ; i < n ; i++){
        if (i < a-1) ma.insert(info[i]);
        else if (i < b) mab.insert(info[i]);
        else mb.insert(info[i]);
    }

    while(l--){
        int x = *mab.begin();
        int y = *mab.rbegin();

        mab.erase(mab.begin());
        mab.erase(next(mab.end(), -1));

        int temp1 = y-x;
        int temp2 = floor((x+y)/2.0);

        // temp1
        if (!ma.empty() && temp1 < *ma.rbegin()){
            ma.insert(temp1);
            mab.insert(*ma.rbegin());
            ma.erase(next(ma.end(), -1));
        } else if (!mb.empty() && temp1 > *mb.begin()){
            mb.insert(temp1);
            mab.insert(*mb.begin());
            mb.erase(mb.begin());
        } else {
            mab.insert(temp1);
        }

        // temp2
        if (!ma.empty() && temp2 < *ma.rbegin()){
            ma.insert(temp2);
            mab.insert(*ma.rbegin());
            ma.erase(next(ma.end(), -1));
        } else if (!mb.empty() && temp2 > *mb.begin()){
            mb.insert(temp2);
            mab.insert(*mb.begin());
            mb.erase(mb.begin());
        } else {
            mab.insert(temp2);
        }
    }

    for (auto i : ma){
        cout << i << " ";
    }
    for (auto i : mab){
        cout << i << " ";
    }
    for (auto i : mb){
        cout << i << " ";
    }
}

/*5 3
1 3
40
20
10
30
50*/