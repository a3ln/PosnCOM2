#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> net(n, vector<int>(3));
    int maxx = 0;
    for (int i = 0 ; i < n ; i++){
        // start, end, weight
        cin >> net[i][0] >> net[i][1] >> net[i][2];
        maxx = max(maxx, net[i][1]);
    }

    vector<int> keep(maxx+1);
    for (int i = 0 ; i < n ; i++){
        for (int j = net[i][0] ; j <= net[i][1] ; j++){
            keep[j] += net[i][2];
        }
    }

    int x = 0, y = 0;
    for (int i = 0 ; i < keep.size() ; i++){
        if (i==0 && keep[i]>=m) x = i;
        else if (keep[i]>=m && keep[i-1]<m) x = i;
        if (i==keep.size()-1 && keep[i]>=m) {
            y = i;
            cout << x << " " << y << "\n";
        } else if (keep[i]>=m && keep[i+1]<m){
            y = i;
            cout << x << " " << y << "\n";
        }
    }
}