#include<bits/stdc++.h>
using namespace std;

int main(){
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m;
    cin >> n >> m;
    vector<int> c(n+1, 0);
    vector<int> b(n+1, 0);
    for (int i = 1 ; i <= n ; i++){
        int num;
        cin >> num;
        if (num < 0) {
            c[i] = c[i-1]-num;
            b[i] = b[i-1];
        } else {
            c[i] = c[i-1];
            b[i] = b[i-1]+num;
        }
    }

    vector<int> ans;
    for (int i = 0 ; i < m ; i++){
        int s, p;
        cin >> s >> p;

        p+=c[s];
        auto it = lower_bound(c.begin(), c.end(), p)-c.begin();
        ans.push_back(b[it-1]-b[s]);
    }

    // for (auto i : b) cout << i << " ";
    // cout << "\n";
    for (auto i : ans){
        cout << i << "\n";
    }
}

/*8 6
-10 -3 5 6 -20 3 4 0
0 3
0 13
0 14
2 1
2 500000000
6 1*/